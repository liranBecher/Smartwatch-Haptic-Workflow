﻿# Agent V2 Retrieval Configuration

## Provider Decision

Release 1 provider: OpenAI hosted vector stores and File Search

InfraNodus enabled: No

Reason:

- existing OpenAI integration
- hosted document parsing and retrieval
- no additional database infrastructure
- project can add InfraNodus later without changing the app-facing
  /webhook/chat contract

## n8n Credential

OpenAI credential name:

Do not store the API key in this file.

## Project Context Store

Name: smartwatch-haptic-project-dev
Vector store ID:
Status:

### Files

| File | Status | Notes |
|---|---|---|
| knowledge_base.md | | |
| agent_v2_implementation.md | | |
| agent_user_stories.md | | |
| agent_v2_system_context.md | | |

## Literature Store

Name: smartwatch-haptic-literature-dev
Vector store ID:
Status:

### Files

| Paper | Author/year | Status | Notes |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

## Planned Expert Connections

| Expert | Retrieval source |
|---|---|
| Project Context Expert | smartwatch-haptic-project-dev |
| Literature Expert | smartwatch-haptic-literature-dev |
| Mapping Design Expert | Live DB context plus optional project store |
| Participant Data Expert | Live DB only |
| Workflow/N8N Expert | Project store plus live workflow context |
| Safety and Feedback Burden Expert | Live DB plus literature store |

## Test Results

### Project retrieval test

Question:

Which workflow owns deterministic mapping writes, and why should the
expert panel not directly modify mapping rows?

Expected concepts:

- Mapping Manager owns mapping mutations
- expert panel is read-only
- explicit confirmation is required before commit

Result:

### Literature retrieval test

Question:

What evidence from the uploaded literature is relevant to designing
wearable vibration feedback?

Result:

### Citation check

- Returned sources correspond to uploaded files:
- No invented source names:
