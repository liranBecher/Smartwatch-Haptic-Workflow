﻿# Agent V2 Implementation Plan

This plan updates Agent V2 against the current live n8n workflows, the current `ResearcherSideApp-FULL` code, and `Smartwatch-Haptic-Workflow/DB_rule_user.sql` as of 2026-06-13.

The important new input is the live n8n workflow:

- `AI Chatbot Agent with a Panel of Experts using InfraNodus GraphRAG Knowledge`

That workflow is an online template. It is not connected to the current system yet, and it should not be copied into production as-is. Its useful architectural idea is the agent shape: one conversational agent, memory, a model, and a set of callable expert tools backed by retrieval/GraphRAG. In this system, that pattern should become the basis of the AI chatbot agent, while deterministic database writes remain in the existing manager workflows.

## Inputs Reviewed

Local files:

- `agent_user_stories.txt`
- `ResearcherSideApp-FULL/com/example/demo/controller/AgentChatTabController.java`
- `ResearcherSideApp-FULL/com/example/demo/controller/DashboardController.java`
- `ResearcherSideApp-FULL/com/example/demo/controller/MappingsTabController.java`
- `ResearcherSideApp-FULL/com/example/demo/controller/YellowBookTabController.java`
- `ResearcherSideApp-FULL/com/example/demo/service/ApiService.java`
- `Smartwatch-Haptic-Workflow/DB_rule_user.sql`
- local workflow exports under `Smartwatch-Haptic-Workflow/`

Live n8n workflows checked through the n8n MCP:

- `Chat Orchestrator` (`6HLjUnFkjKxhDhsb`, active, `/webhook/chat`)
- `Mapping Manager` (`6mbZSpha6phxwD1v`, active)
- `Knowledge Agent` (`NBGENe1uYYpTnN5l`, active)
- `DB Manager` (`nFeUS2F9bOFH6AUd`, active)
- `Vibration Orchestrator` (`TzWBOI6V0lfIepbF`, active)
- `Dictionary Manager` (`uqv2x7unjvI0y4nt`, active)
- `Schedule Manager` (`UqOtVUntzN2Gh75O`, active)
- `Use Case Builder` (`Z41Dn3edCcUEwQCO`, active)
- `AI Chatbot Agent with a Panel of Experts using InfraNodus GraphRAG Knowledge` (`kDCD9jwktkVrpby6`, inactive)

## Executive Decision

Use the InfraNodus template as the conceptual base for the agent backend, but do not make the JavaFX app call that template directly.

Recommended target architecture:

1. Keep `Chat Orchestrator` as the app-facing `/chat` webhook.
2. Convert `Chat Orchestrator` from a simple classifier plus router into the main agent gateway.
3. Add a new internal workflow, or refactor the existing template, as `GraphRAG Expert Panel Agent`.
4. Replace the template's generic `EightOS Expert` and `Polysingularity Expert` tools with project-specific expert tools:
   - `Project Context Expert`
   - `Literature Expert`
   - `Mapping Design Expert`
   - `Participant Data Expert`
   - `Workflow/N8N Expert`
   - `Safety and Feedback Burden Expert`
5. Keep all database-changing actions in deterministic workflows:
   - `Mapping Manager`
   - `DB Manager`
   - `Dictionary Manager`
   - `Schedule Manager`
   - `Use Case Builder`
6. Add persistent draft state in the DB so the agent can brainstorm, refine, select, simulate, and commit proposals across multiple messages.

This gives us the best part of the template, which is an agent with expert retrieval tools, without losing the current app contract or allowing an LLM tool to mutate the database directly.

## Current System Snapshot

### ResearcherSideApp-FULL

The app is a JavaFX dashboard. The AI chat lives in `AgentChatTabController`.

Current behavior:

- `ApiService.BASE_URL` points to `http://localhost:5678/webhook`.
- `ApiService.EP_CHAT_CONFIG` is `/chat`.
- `AgentChatTabController` posts every chat message to `/chat`.
- The chat payload already includes useful context:
  - `message`
  - `session_id`
  - `usecase_id`
  - `usecase_name`
  - `user_id`
  - `user_name`
  - `user_usecase_id`
  - `user_usecase_name`
  - `user_mapping_id`
- The chat UI currently renders only the `reply` field.
- The app has chat shortcuts for mapping, knowledge, dictionary, and schedule requests.
- Direct app actions for mapping assignment and mapping changes already call `/chat`.
- Direct app actions for use-case assignment, user creation, schedules, dictionary editing, and monitoring config use specific endpoints from `DB Manager` or related workflows.

Important implication:

- The backend must keep returning `reply`, even after structured response fields are added.
- The JavaFX app does not need to know whether the response came from `Mapping Manager`, `Knowledge Agent`, or the new GraphRAG expert panel.
- Any future proposal cards, citations, actions, or warnings must be additive fields.

### Current Chat Orchestrator

Live `Chat Orchestrator` is the `/webhook/chat` entrypoint.

Current flow:

1. `Webhook`
2. `Validate input`
3. `Session Upsert`
4. `Load Context` from `v_agent_context`
5. `Build prompt`
6. `Basic LLM Chain`
7. `Parse GPT Response`
8. `Intent Router`
9. Execute one manager workflow:
   - `Mapping Manager`
   - `Knowledge Agent`
   - `Dictionary Manager`
   - `Schedule Manager`
   - `Use Case Builder`
10. `Respond to Webhook`
11. `Save History`

Current limitations:

- It is mainly an intent classifier, not a full agent.
- It uses a single prompt and basic chain, while the template uses an agent with memory and tools.
- It does not load or update draft artifacts.
- It does not yet have structured response types for proposals, citations, warnings, or UI actions.
- It does not have a project-specific retrieval layer.
- It contains query replacement patterns that should be converted to array replacements, especially `Session Upsert`, `Load Context`, and `Save History`.

### Current Knowledge Agent

Live `Knowledge Agent` is an internal workflow. It currently has:

- `Execute Workflow Trigger`
- `DB - fetch mappings`
- `Package mappings`
- `GPT - Knowledge`
- `OpenAI Chat Model`
- `Format - response`

This is the right place for experiment explanations today, but it is too small to become the complete Agent V2 backend by itself.

Recommended change:

- Keep `Knowledge Agent` for deterministic knowledge responses and simple DB-grounded explanations.
- Add or refactor a separate `GraphRAG Expert Panel Agent` for multi-expert retrieval and higher quality reasoning.
- Let `Chat Orchestrator` choose when to call `Knowledge Agent` versus the expert panel.

### Current Mapping Manager

Live `Mapping Manager` supports:

- `list`
- `listAll`
- `add`
- `remove`
- `change`
- `duplicate_mapping_for_user`
- `assign`
- `brainstorm`

Current limitations:

- `brainstorm` is single-turn and text-only.
- It does not persist draft proposals.
- It does not support refine, select, commit, cancel, or simulate.
- Mapping assignment should be checked for deterministic single-row lookup and active-history handling.

Recommended change:

- Keep `Mapping Manager` as the deterministic owner of mapping mutations.
- Extend it with draft-aware mapping actions:
  - `brainstorm_start`
  - `brainstorm_refine`
  - `brainstorm_select`
  - `brainstorm_commit`
  - `brainstorm_cancel`
  - `simulate_mapping`
  - `feedback_burden_check`
  - `explain_mapping`

### Current DB and Runtime Constraints

`DB_rule_user.sql` confirms:

- `agent_session` exists.
- `agent_artifact` does not exist yet.
- `v_agent_context` exists.
- `feedback_config_rules` stores mapping ranges and vibration parameters.
- `User_UC_Mappings` stores mapping assignments with history fields:
  - `id`
  - `user_id`
  - `feedback_config_rule_id`
  - `active`
  - `assigned_at`
  - `deactivated_at`
- `user_uc_mappings_one_active_per_user` enforces one active mapping per user globally.
- `insert_sensor_data(...)` rejects data if the user's active mapping resolves to a different use case.
- `resolve_fb_range(...)` first checks the selected user's active mapping for the incoming use case, then falls back to global active rules.

Product implication:

- Release 1 must treat the system as one active mapping per user globally.
- If we later want one active mapping per user per use case, that is a coordinated DB and runtime change. It cannot be implemented only in the chatbot.

### Current Vibration Orchestrator

`Vibration Orchestrator` is the runtime workflow. It has a generic `/usecase-routing` webhook, routes sensor/use-case requests, fetches active rules, prefers user-specific assignments, falls back to global rules, rate-limits feedback, and logs results through `insert_sensor_data(...)`.

Agent V2 must use this as the source of truth for runtime behavior. Proposed mappings are only valid if they work with this runtime selection model.

## InfraNodus Template Assessment

The template workflow is currently inactive and has a chat trigger, not a webhook trigger.

Template nodes:

- `When chat message received`
- `Simple Memory`
- `AI Agent`
- `OpenAI Chat Model`
- `EightOS Expert`
- `Polysingularity Expert`
- several sticky notes

Template behavior:

- The chat trigger is public and asks the user for a question.
- The `AI Agent` system prompt requires using at least one expert tool before answering.
- The expert tools are HTTP request tools that call the InfraNodus API endpoint:
  - `https://infranodus.com/api/v1/graphAndAdvice?...`
- The template has two specific expert graphs:
  - `panarchy_eightos`
  - `polysingularity_overview`

What is useful:

- Agent node with callable tools.
- Expert panel pattern.
- GraphRAG retrieval through HTTP tools.
- Memory attached to the agent.
- Requirement that the model consult at least one expert source before answering.

What must change:

- Replace the chat trigger with an internal `Execute Workflow Trigger`, or keep the template inactive and call its logic from `Chat Orchestrator`.
- Replace the generic template expert topics with project-specific expert tools.
- Replace public chat UI behavior with the existing `/webhook/chat` contract used by JavaFX.
- Remove the hard rule to always use `EightOS` or `Polysingularity`; use the right project expert based on intent.
- Add structured output and mutation guardrails.
- Add DB context and current app context.
- Do not let the expert panel directly execute DB mutations.

## Target Architecture

### High-Level Flow

JavaFX app:

```text
ResearcherSideApp-FULL
  -> POST /webhook/chat
  -> Chat Orchestrator
```

Chat Orchestrator:

```text
Validate input
Session Upsert
Load DB context
Load open agent artifacts
Classify/request-plan
Route:
  - deterministic action -> manager workflow
  - knowledge/reasoning/retrieval -> GraphRAG Expert Panel Agent
  - mixed request -> expert panel drafts a plan, manager workflow commits only after approval
Save history
Respond with reply plus structured fields
```

GraphRAG Expert Panel Agent:

```text
Execute Workflow Trigger
Build expert-panel input
AI Agent
OpenAI Chat Model
Memory or DB-backed session history
Project-specific expert tools
Format structured response
```

Manager workflows:

```text
Mapping Manager      -> mapping read/write, brainstorm artifacts, assignment
Knowledge Agent      -> simple DB-grounded explanations
DB Manager           -> users, use cases, monitoring config, current configurations
Dictionary Manager   -> use-case dictionary
Schedule Manager     -> schedules
Use Case Builder     -> implementation guidance for new use cases
Vibration Orchestrator -> runtime only, not called for ordinary chat except simulation/review references
```

### Why Not Make the Template the Main `/chat` Endpoint?

Do not point JavaFX directly at the template because:

- It uses a chat trigger, while the app uses a webhook endpoint.
- It does not know the app payload contract.
- It does not know selected use case/user/mapping context.
- It does not route deterministic actions to the existing workflows.
- It does not protect DB writes.
- It depends on external InfraNodus graphs that are unrelated to the haptic project.

Instead, use the template architecture inside the backend.

## Required Response Contract

All `/chat` responses must keep this minimal shape:

```json
{
  "reply": "Plain text response for the current JavaFX chat bubble.",
  "session_id": "..."
}
```

Add structured fields without breaking old rendering:

```json
{
  "reply": "I drafted three options. No changes were saved yet.",
  "session_id": "...",
  "success": true,
  "intent": "mapping",
  "action": "brainstorm_start",
  "state": {
    "artifact_id": 42,
    "artifact_type": "mapping_brainstorm",
    "status": "draft"
  },
  "proposals": [],
  "warnings": [],
  "citations": [],
  "actions": []
}
```

Assignment and mutation responses must keep success language in `reply` or `message` because `ApiService.assignMappingToUser(...)` currently checks text for:

- `assigned`
- `updated`
- `now active`
- `success`

## Database Changes

### Add Agent Artifact State

Create `Smartwatch-Haptic-Workflow/agent_artifact_migration.sql`.

```sql
BEGIN;

CREATE TABLE IF NOT EXISTS public.agent_artifact (
    id bigserial PRIMARY KEY,
    session_id uuid NOT NULL REFERENCES public.agent_session(session_id) ON DELETE CASCADE,
    artifact_type text NOT NULL,
    status text NOT NULL DEFAULT 'draft',
    usecase_id integer REFERENCES public."UseCase"(usecase_id),
    user_id integer REFERENCES public."User"(userid),
    title text,
    payload jsonb NOT NULL DEFAULT '{}'::jsonb,
    evidence jsonb NOT NULL DEFAULT '[]'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT agent_artifact_status_check
      CHECK (status IN ('draft', 'needs_clarification', 'selected', 'committed', 'cancelled', 'failed'))
);

CREATE INDEX IF NOT EXISTS idx_agent_artifact_session_status
ON public.agent_artifact(session_id, artifact_type, status, updated_at DESC);

CREATE INDEX IF NOT EXISTS idx_agent_artifact_usecase_user
ON public.agent_artifact(usecase_id, user_id, artifact_type, status);

DROP TRIGGER IF EXISTS trg_agent_artifact_updated_at ON public.agent_artifact;
CREATE TRIGGER trg_agent_artifact_updated_at
BEFORE UPDATE ON public.agent_artifact
FOR EACH ROW
EXECUTE FUNCTION public.touch_updated_at();

COMMIT;
```

Release 1 artifact types:

- `mapping_brainstorm`
- `pending_mapping_change`
- `workflow_draft`
- `simulation_request`
- `clarification`
- `expert_panel_answer`

### Mapping Brainstorm Payload

```json
{
  "version": 1,
  "usecase_id": 1,
  "usecase_name": "HeartRate",
  "target_user_id": 100,
  "selected_proposal_id": null,
  "created_mapping_id": null,
  "assigned_record_id": null,
  "proposals": [
    {
      "proposal_id": "p1",
      "label": "Gentle awareness",
      "params": {
        "minvalue": 80,
        "maxvalue": 100,
        "minpulses": 2,
        "maxpulses": 4,
        "minintensity": 80,
        "maxintensity": 140,
        "minduration": 150,
        "maxduration": 220,
        "mininterval": 900,
        "maxinterval": 1400
      },
      "rationale": "",
      "warnings": [],
      "source_refs": []
    }
  ]
}
```

## Expert Panel Design

Refactor the template into a project-specific internal workflow named:

- `GraphRAG Expert Panel Agent`

Use either:

1. a new workflow based on the template, or
2. the existing template workflow renamed and heavily modified.

Recommended: create a new workflow from the template and leave the original inactive as a reference until the new one is stable.

### Trigger

Replace the template chat trigger with:

- `Execute Workflow Trigger`

Input contract:

```json
{
  "session_id": "...",
  "message": "...",
  "intent": "knowledge",
  "usecase_id": 1,
  "usecase_name": "HeartRate",
  "user_id": 100,
  "user_mapping_id": 140,
  "context": {},
  "open_artifacts": []
}
```

### Expert Tools

Replace `EightOS Expert` and `Polysingularity Expert` with project-specific tools.

#### Project Context Expert

Purpose:

- answer from project documentation and system architecture
- explain component responsibilities
- explain how JavaFX, n8n, DB, Android, and smartwatch interact

Sources:

- `knowledge_base.md`
- Notion documentation later
- workflow summaries
- app file references

#### Literature Expert

Purpose:

- answer haptics, sensory substitution, interoception, biofeedback, thermal feedback, and wearable feedback questions
- cite required papers

Sources:

- required papers vector store
- optional web/current sources only when explicitly needed

#### Mapping Design Expert

Purpose:

- propose mapping options
- refine vibration parameters
- explain mapping tradeoffs
- generate structured proposals

Sources:

- `feedback_config_rules`
- selected use case
- selected user context
- mapping history
- recent sensor statistics

#### Participant Data Expert

Purpose:

- analyze whether a selected participant needs personalization
- summarize recent readings
- identify feedback burden

Sources:

- `SensorData`
- `Alert`
- `User_UC_Mappings`
- `/users-mappings-history` query shape

#### Workflow/N8N Expert

Purpose:

- explain how to add a new use case
- review whether a proposed workflow fits `Vibration Orchestrator`
- identify which n8n nodes must be changed

Sources:

- `Vibration Orchestrator`
- `Use Case Builder`
- `Dictionary Manager`
- current workflow exports

#### Safety and Feedback Burden Expert

Purpose:

- flag overly intense or frequent vibration designs
- detect likely over-triggering
- recommend safer thresholds, durations, intervals, and intensity ranges

Sources:

- recent sensor and alert data
- mapping proposal
- runtime rate-limiting assumptions

### InfraNodus Integration Options

Use InfraNodus in one of two ways:

1. Keep HTTP request tools to InfraNodus, but change the graph names and prompts to project-specific knowledge graphs.
2. Replace InfraNodus HTTP tools with OpenAI vector store retrieval or another retrieval service, while keeping the expert-panel pattern.

Recommended first implementation:

- Use OpenAI vector store retrieval for required papers and project docs if it is easier to configure.
- Keep InfraNodus support optional behind configuration.
- Do not block Agent V2 on building perfect GraphRAG infrastructure.

## Chat Orchestrator Changes

### Load Open Artifacts

After `Load Context`, add a Postgres node:

```sql
SELECT id, artifact_type, status, usecase_id, user_id, title, payload, evidence, updated_at
FROM public.agent_artifact
WHERE session_id = $1
  AND usecase_id = $2
  AND status IN ('draft', 'needs_clarification', 'selected')
ORDER BY updated_at DESC, id DESC
LIMIT 5;
```

Use array replacement:

```text
={{ [$('Validate input').item.json.session_id, $('Validate input').item.json.usecase_id] }}
```

### Replace Basic Classification With Agent Planning

Update `Build prompt` and routing to produce:

```json
{
  "intent": "mapping | knowledge | dictionary | scheduling | usecase_builder | clarify",
  "action": "brainstorm_start | brainstorm_refine | brainstorm_select | brainstorm_commit | list | assign | explain | answer | ...",
  "requires_confirmation": false,
  "read_only": true,
  "target_workflow": "Mapping Manager | Knowledge Agent | GraphRAG Expert Panel Agent | ...",
  "payload": {},
  "reply": ""
}
```

Routing rules:

- Read-only explanations and research questions can go to `GraphRAG Expert Panel Agent`.
- Simple mapping lists stay in `Mapping Manager`.
- Mapping drafts are handled by `Mapping Manager`, optionally after expert-panel advice.
- Confirmed mapping commits stay in `Mapping Manager`.
- Dictionary edits stay in `Dictionary Manager`.
- Schedule edits stay in `Schedule Manager`.
- Use-case implementation guidance goes to `Use Case Builder`, optionally enriched by `Workflow/N8N Expert`.
- Clarification creates or updates a `clarification` artifact.

### Fix Query Replacement Patterns

Convert scalar replacements to arrays where multiple parameters are used.

Examples:

`Session Upsert`:

```text
={{ [$json.session_id, $json.usecase_id] }}
```

`Load Context`:

```text
={{ [$json.session_id] }}
```

`Save History`:

```text
={{ [
  $json.session_id,
  JSON.stringify([
    { role: 'user', content: $('Build prompt').first().json.message },
    { role: 'assistant', content: $json.reply }
  ])
] }}
```

## Mapping Manager Changes

### Preserve Existing Direct App Behavior

Do not break:

- `ApiService.assignMappingToUser(...)`
- `ApiService.changeMapping(...)`
- `ApiService.changeMappingForUserOnly(...)`
- `MappingsTabController` direct assignment and edits

`Mapping Manager` must still accept:

- `assign_mapping_to_user`
- `assign`
- `change`
- `duplicate_mapping_for_user`

Normalize aliases in `Parse incoming`:

```javascript
const aliases = {
  assign_mapping_to_user: 'assign',
  brainstorm: 'brainstorm_start'
};
action = aliases[action] ?? action;
```

### Deterministic Assignment Fixes

`DB - Find Mapping` should use a deterministic single-row lookup:

```sql
SELECT id
FROM public."User_UC_Mappings"
WHERE user_id = $1
  AND feedback_config_rule_id = $2
ORDER BY active DESC, assigned_at DESC, id DESC
LIMIT 1;
```

Use replacement:

```text
={{ [$('Validate - assign params').item.json.user_id, $('Validate - assign params').item.json.mapping_id] }}
```

`DB - Disconnect from mapping1` should keep Release 1 global behavior:

```sql
UPDATE public."User_UC_Mappings"
SET active = false,
    deactivated_at = NOW()
WHERE user_id = $1
  AND active = true;
```

Use replacement:

```text
={{ [$json.user_id] }}
```

`DB - set mapping true` should clear `deactivated_at`:

```sql
UPDATE public."User_UC_Mappings"
SET active = true,
    deactivated_at = NULL,
    assigned_at = NOW()
WHERE id = $1
RETURNING id;
```

### Draft Mapping Actions

Add these actions:

- `brainstorm_start`
- `brainstorm_refine`
- `brainstorm_select`
- `brainstorm_commit`
- `brainstorm_cancel`
- `simulate_mapping`

Rules:

- `brainstorm_start` creates a draft artifact and returns proposals.
- `brainstorm_refine` updates the artifact, preserving stable proposal IDs.
- `brainstorm_select` marks a proposal as selected, but does not write mapping rows.
- `brainstorm_commit` creates or reuses a mapping and optionally assigns it to a user.
- `brainstorm_cancel` marks the draft cancelled.
- `simulate_mapping` uses historical `SensorData` and does not mutate anything.

The expert panel can help generate or critique proposals, but `Mapping Manager` owns persistence and commit.

## Knowledge and Expert Routing

Use `Knowledge Agent` for narrow DB-grounded responses:

- "show/explain current mappings"
- "what does mapping 140 do?"
- "summarize this use case from DB context"

Use `GraphRAG Expert Panel Agent` for broader reasoning:

- brainstorming new mappings
- comparing design options
- answering literature-backed questions
- reviewing a planned new use case
- explaining experiment design
- interpreting participant data with haptics context
- generating presentation-friendly summaries

When the answer needs both:

1. Query deterministic DB context first.
2. Pass that context into the expert panel.
3. Return a grounded answer with citations and warnings.

## JavaFX App Changes

### Release 1 App Changes

Minimal app changes:

1. Keep `postWithResponse(ApiService.EP_CHAT_CONFIG, payload)`.
2. Keep rendering `reply`.
3. Add new chat commands:

```java
options.add(new ChatCommandOption("$brainstorm", "Brainstorm Mapping", "Design draft mapping options for the selected use case", "brainstorm mapping options for this use case"));
options.add(new ChatCommandOption("$personalize", "Personalize User", "Analyze whether the selected user needs a custom mapping", "does the selected user need a personalized mapping?"));
options.add(new ChatCommandOption("$burden", "Feedback Burden", "Check whether participants are receiving too many vibrations", "check feedback burden for this use case"));
options.add(new ChatCommandOption("$review", "Review Workflow", "Review the current workflow for safety and clarity", "review this workflow before activation"));
options.add(new ChatCommandOption("$simulate", "Simulate Draft", "Estimate draft behavior using historical data", "simulate the current draft using recent data"));
options.add(new ChatCommandOption("$summary", "Experiment Summary", "Summarize the selected experiment setup", "summarize this experiment setup"));
```

### Release 2 App Changes

Add typed response models:

- `AgentChatResponse`
- `AgentChatState`
- `AgentSuggestion`
- `AgentAction`
- `AgentCitation`
- `MappingProposal`
- `MappingProposalParams`
- `AgentIssue`

Add `ApiService.sendAgentChat(Map<String, Object> payload)` returning `AgentChatResponse`.

Add structured rendering:

- proposal cards
- action buttons
- citations
- warning blocks
- draft state summary
- simulation summary

Action buttons should send normal chat messages back to `/chat`, such as:

- `select proposal p2`
- `make proposal p2 gentler`
- `commit selected proposal and assign to user 100`
- `cancel this draft`
- `simulate this draft using the last 7 days`

## Chronological Implementation Plan

### Step 1: Freeze the Current Live Baseline

Owner: You for live n8n export, Codex can assist.

Goal:

- Make sure all later work is based on the real live workflows, not stale local JSON.

What to do:

1. Use n8n MCP or n8n export to fetch these live workflows:
   - `Chat Orchestrator`
   - `Mapping Manager`
   - `Knowledge Agent`
   - `DB Manager`
   - `Vibration Orchestrator`
   - `Dictionary Manager`
   - `Schedule Manager`
   - `Use Case Builder`
   - `AI Chatbot Agent with a Panel of Experts using InfraNodus GraphRAG Knowledge`
2. Save a dated rollback copy of every exported workflow.
3. Compare each live export to the matching local file under `Smartwatch-Haptic-Workflow/`.
4. If live differs from local, update the local file or add a note explaining why local should not be overwritten.
5. Record workflow IDs, active state, trigger paths, and whether each workflow is MCP-visible.

Deliverable:

- A baseline note listing workflow IDs and rollback file locations.
- Local workflow JSON that matches live n8n, or a clear exception note.

Validation:

- `Chat Orchestrator` still exposes `/webhook/chat`.
- Existing app chat requests still return a `reply`.
- The InfraNodus template is confirmed inactive and not yet connected to production chat.

### Step 2: Confirm the Current DB Contract

Owner: Shared. Codex can prepare SQL checks; you run them against the live/dev DB.

Goal:

- Confirm the agent will respect the real data model before adding draft state or new mutation flows.

What to do:

1. Confirm `agent_session` exists.
2. Confirm `agent_artifact` does not already exist, or inspect it if it does.
3. Confirm `user_uc_mappings_one_active_per_user` exists.
4. Confirm `feedback_config_rules`, `User_UC_Mappings`, `SensorData`, `Alert`, `UseCase`, `UseCaseDictionary`, and `api_pool` match `DB_rule_user.sql`.
5. Run checks for duplicate historical assignment rows:

```sql
SELECT user_id, feedback_config_rule_id, COUNT(*) AS row_count
FROM public."User_UC_Mappings"
GROUP BY user_id, feedback_config_rule_id
HAVING COUNT(*) > 1
ORDER BY row_count DESC;
```

6. Run checks for multiple active mappings per user:

```sql
SELECT user_id, COUNT(*) AS active_count
FROM public."User_UC_Mappings"
WHERE active = true
GROUP BY user_id
HAVING COUNT(*) > 1;
```

Deliverable:

- A DB contract note confirming Release 1 uses one active mapping per user globally.

Validation:

- If the DB has one-active-mapping-per-user globally, the agent plan keeps that behavior.
- If the product needs one active mapping per user per use case, pause Agent V2 mutation work and plan a coordinated DB/runtime migration first.

### Step 3: Choose the Retrieval and GraphRAG Backend

Owner: You for credentials/config, Codex can wire workflow changes.

Goal:

- Decide what the expert panel will actually retrieve from.

What to do:

1. Choose one of these approaches:
   - InfraNodus only, with new project-specific graphs.
   - OpenAI vector store only, with required papers and project docs.
   - Hybrid: InfraNodus for graph analysis, OpenAI vector store for paper/project retrieval.
2. List the required source collections:
   - required papers
   - `knowledge_base.md`
   - current Notion documentation later
   - workflow summaries
   - DB schema summary
   - ResearcherSideApp architecture summary
3. Define which workflow credentials are needed:
   - OpenAI credential in n8n
   - InfraNodus bearer token if used
   - any vector store IDs or graph names
4. Create a small config note with env variables, credential names, and source IDs.

Recommended first choice:

- Use OpenAI vector store or simple project-doc retrieval first.
- Keep InfraNodus optional until project-specific graphs exist.

Deliverable:

- A provider decision note.
- A credential/config checklist.

Validation:

- A test retrieval question returns grounded context from at least one configured source.
- If no retrieval provider is ready, the agent still works with DB context and returns no fake citations.

### Step 4: Add Persistent Agent Artifact State

Owner: Codex can create SQL; you apply it in dev/live DB.

Goal:

- Give the chatbot durable state for multi-turn brainstorms, selected options, pending confirmations, and simulation requests.

What to do:

1. Create `Smartwatch-Haptic-Workflow/agent_artifact_migration.sql`.
2. Add the `public.agent_artifact` table.
3. Add indexes for session/status lookup and usecase/user lookup.
4. Add the `updated_at` trigger using `touch_updated_at()`.
5. Apply the migration in dev.
6. Insert and update one test artifact manually.
7. Confirm delete cascade from `agent_session` behaves as expected in dev only.

Deliverable:

- `agent_artifact_migration.sql`
- A short DB verification note.

Validation:

- `SELECT * FROM public.agent_artifact LIMIT 1;` works.
- Open draft artifacts can be queried by `session_id` and `usecase_id`.

### Step 5: Stabilize Current Mapping Assignment Before New Agent Work

Owner: Codex can update workflow JSON; you import/publish in n8n.

Goal:

- Make existing direct mapping assignment reliable before adding more chatbot paths that depend on it.

What to do in `Mapping Manager`:

1. In `Parse incoming`, normalize action aliases:

```javascript
const aliases = {
  assign_mapping_to_user: 'assign',
  brainstorm: 'brainstorm_start'
};
action = aliases[action] ?? action;
```

2. Update `DB - Find Mapping`:

```sql
SELECT id
FROM public."User_UC_Mappings"
WHERE user_id = $1
  AND feedback_config_rule_id = $2
ORDER BY active DESC, assigned_at DESC, id DESC
LIMIT 1;
```

3. Use array replacement for `DB - Find Mapping`:

```text
={{ [$('Validate - assign params').item.json.user_id, $('Validate - assign params').item.json.mapping_id] }}
```

4. Update `DB - Disconnect from mapping1` to deactivate the selected user's current active mapping:

```sql
UPDATE public."User_UC_Mappings"
SET active = false,
    deactivated_at = NOW()
WHERE user_id = $1
  AND active = true;
```

5. Use array replacement:

```text
={{ [$json.user_id] }}
```

6. Update reactivation to clear `deactivated_at`:

```sql
UPDATE public."User_UC_Mappings"
SET active = true,
    deactivated_at = NULL,
    assigned_at = NOW()
WHERE id = $1
RETURNING id;
```

7. Confirm `ApiService.assignMappingToUser(...)` still works without Java code changes.

Deliverable:

- Updated `Mapping Manager` workflow.
- Regression note for direct app assignment and chat assignment.

Validation:

- Assigning an existing mapping to a user returns success language.
- The user has only one active mapping after assignment.
- Historical duplicate rows do not cause scalar subquery errors.

### Step 6: Create the Project-Specific Expert Panel Workflow

Owner: Shared.

Goal:

- Convert the useful template pattern into an internal expert-panel workflow for this project.

What to do:

1. Duplicate or recreate the InfraNodus template as a new workflow named `GraphRAG Expert Panel Agent`.
2. Replace `When chat message received` with `Execute Workflow Trigger`.
3. Keep the agent pattern:
   - `AI Agent`
   - `OpenAI Chat Model`
   - memory, if useful
   - tool calls
4. Remove or disable the original `EightOS Expert` and `Polysingularity Expert` tools.
5. Add project-specific tools:
   - `Project Context Expert`
   - `Literature Expert`
   - `Mapping Design Expert`
   - `Participant Data Expert`
   - `Workflow/N8N Expert`
   - `Safety and Feedback Burden Expert`
6. Add a `Format response` code node that enforces:

```json
{
  "reply": "",
  "citations": [],
  "warnings": [],
  "proposals": [],
  "recommended_actions": []
}
```

7. Keep the original template inactive until the new workflow is stable.

Deliverable:

- New internal `GraphRAG Expert Panel Agent` workflow.
- The original InfraNodus template remains available as reference.

Validation:

- Manual execution with an input payload returns valid JSON.
- The workflow can answer a read-only knowledge question without mutating DB state.
- If retrieval credentials are missing, the workflow returns a clear configuration warning rather than hallucinated citations.

### Step 7: Update Chat Orchestrator Into the Main Agent Gateway

Owner: Codex can update workflow JSON; you import/publish in n8n.

Goal:

- Keep `/webhook/chat` stable while making it route to the new expert panel and draft-aware managers.

What to do in `Chat Orchestrator`:

1. Keep the existing `Webhook` path `/chat`.
2. Keep `Validate input`, but ensure it passes through all app context fields:
   - `user_id`
   - `user_name`
   - `user_mapping_id`
   - `user_usecase_id`
   - `user_usecase_name`
3. Fix query replacements in:
   - `Session Upsert`
   - `Load Context`
   - `Save History`
4. Add `Load Open Artifacts` after `Load Context`.
5. Update `Build prompt` to include:
   - selected use case
   - selected user
   - selected mapping
   - active mappings
   - recent conversation history
   - open artifacts
   - one-active-mapping-per-user rule
6. Replace the simple classifier output with a planner output:

```json
{
  "intent": "mapping | knowledge | dictionary | scheduling | usecase_builder | clarify",
  "action": "",
  "target_workflow": "",
  "read_only": true,
  "requires_confirmation": false,
  "payload": {},
  "reply": ""
}
```

7. Add an `Execute Workflow` route to `GraphRAG Expert Panel Agent`.
8. Preserve existing routes to:
   - `Mapping Manager`
   - `Knowledge Agent`
   - `Dictionary Manager`
   - `Schedule Manager`
   - `Use Case Builder`
9. Ensure every route returns through one response-normalization node.
10. Save the final normalized response to `agent_session.conversation_history`.

Deliverable:

- Updated `Chat Orchestrator`.

Validation:

- Existing `$mapping`, `$knowledge`, `$dictionary`, and `$schedule` commands still work.
- Broad knowledge questions route to the expert panel.
- Every response still contains `reply`.

### Step 8: Extend Mapping Manager With Draft-Aware Actions

Owner: Codex can update workflow JSON; you import/publish in n8n.

Goal:

- Support multi-turn mapping design without writing DB changes too early.

What to do:

1. Add action routing for:
   - `brainstorm_start`
   - `brainstorm_refine`
   - `brainstorm_select`
   - `brainstorm_commit`
   - `brainstorm_cancel`
   - `simulate_mapping`
   - `feedback_burden_check`
   - `explain_mapping`
2. `brainstorm_start`:
   - load current mappings
   - load recent user/use-case stats if a user is selected
   - optionally call `GraphRAG Expert Panel Agent` or use its returned proposals
   - create `agent_artifact`
   - return proposal list
3. `brainstorm_refine`:
   - load latest draft artifact
   - apply requested change
   - validate ranges and vibration fields
   - update artifact payload
4. `brainstorm_select`:
   - mark selected proposal ID
   - set artifact status to `selected`
   - do not write mapping rows
5. `brainstorm_commit`:
   - require explicit approval
   - validate selected proposal
   - check for exact duplicate active mapping
   - reuse duplicate or insert new `feedback_config_rules` row
   - assign to user only if requested
   - set artifact status to `committed`
6. `brainstorm_cancel`:
   - set artifact status to `cancelled`
7. `simulate_mapping`:
   - use historical `SensorData`
   - estimate trigger count and alert percentage
   - do not mutate DB
8. `feedback_burden_check`:
   - use `SensorData` and `Alert`
   - identify high-frequency feedback
   - return warnings and suggested draft actions
9. `explain_mapping`:
   - load mapping row and use-case context
   - return plain-language participant experience and technical summary

Deliverable:

- Updated `Mapping Manager`.

Validation:

- A brainstorm can start, refine, select, cancel, and commit.
- No mapping row is inserted before commit.
- Commit uses the same assignment behavior as the current app.

### Step 9: Ground Knowledge and Literature Answers

Owner: Shared.

Goal:

- Make answers useful to researchers instead of generic chatbot text.

What to do:

1. Keep `Knowledge Agent` for quick DB-grounded answers.
2. Add or update DB queries for:
   - selected use case details
   - active mappings
   - selected user's active assignment
   - mapping history
   - recent sensor stats
   - recent alert stats
3. Use `GraphRAG Expert Panel Agent` for:
   - literature-backed answers
   - design comparisons
   - workflow review
   - presentation summaries
4. Add citation output only when a real retrieval source was used.
5. Add a fallback line when retrieval is not configured:
   - "I can answer from the project database and workflow context, but paper retrieval is not configured yet."

Deliverable:

- Updated `Knowledge Agent` and/or expert-panel tools.

Validation:

- A use-case question cites DB context.
- A paper/literature question cites configured retrieval sources.
- The agent does not invent paper citations when retrieval is unavailable.

### Step 10: Add Minimal JavaFX Chat Improvements

Owner: Codex can implement locally.

Goal:

- Give researchers better entry points without requiring the full structured UI yet.

What to do:

1. Update `AgentChatTabController.createChatCommandOptions()`.
2. Add commands:
   - `$brainstorm`
   - `$personalize`
   - `$burden`
   - `$review`
   - `$simulate`
   - `$summary`
3. Keep existing commands:
   - `$mapping`
   - `$knowledge`
   - `$dictionary`
   - `$schedule`
4. Keep `postWithResponse(ApiService.EP_CHAT_CONFIG, payload)`.
5. Keep current `reply` rendering.
6. Refresh mappings/users after successful mutation responses if the response includes an action or success flag.

Deliverable:

- Updated JavaFX command shortcuts.

Validation:

- App compiles.
- Chat commands expand to useful prompts.
- Plain `reply` responses still render.

### Step 11: Add Structured JavaFX Agent UI

Owner: Codex can implement locally.

Goal:

- Render the richer backend responses after the backend contract is stable.

What to do:

1. Add typed models:
   - `AgentChatResponse`
   - `AgentChatState`
   - `AgentSuggestion`
   - `AgentAction`
   - `AgentCitation`
   - `MappingProposal`
   - `MappingProposalParams`
   - `AgentIssue`
2. Add `ApiService.sendAgentChat(Map<String, Object> payload)`.
3. Parse optional fields while keeping fallback for plain `reply`.
4. Render:
   - proposal cards
   - warning blocks
   - citation lists
   - draft status
   - action buttons
5. Action buttons should send normal chat messages back to `/chat`.
6. Add UI error handling for missing optional fields.

Deliverable:

- Structured Agent Chat UI.

Validation:

- Plain responses render.
- Structured proposal responses render.
- Action buttons send follow-up messages.
- Missing citations/proposals/actions do not crash the UI.

### Step 12: Add Mapping-Level Simulation

Owner: Shared.

Goal:

- Let researchers estimate participant impact before committing mapping changes.

What to do:

1. Add a `simulate_mapping` action in `Mapping Manager`.
2. Accept either:
   - selected draft proposal
   - explicit mapping ID
   - explicit parameter set
3. Query recent `SensorData` for selected use case and optional selected user.
4. Apply mapping ranges to historical values.
5. Estimate:
   - number of matching events
   - expected alert percentage
   - busiest time window
   - feedback-burden warning
6. Return `reply`, `simulation`, and `warnings`.

Deliverable:

- Mapping simulation response from `/chat`.

Validation:

- Simulation does not insert or update any DB rows.
- The same draft can be simulated before commit.

### Step 13: Review New Use-Case Workflow Support

Owner: Shared.

Goal:

- Let the agent help researchers design new use cases while respecting `Vibration Orchestrator`.

What to do:

1. Keep direct use-case creation in `DB Manager` via `/create-usecase`.
2. Use `Use Case Builder` for implementation instructions.
3. Use `Workflow/N8N Expert` to review whether `Vibration Orchestrator` already supports the sensor/API type.
4. Produce a `workflow_draft` artifact for new use-case ideas.
5. Include dictionary requirements from `UseCaseDictionary`.
6. Explain which n8n nodes the researcher must edit manually.

Deliverable:

- Draft workflow planning flow for new use cases.

Validation:

- The agent can explain how to add a new use case without creating or publishing n8n workflow changes automatically.
- It identifies when only dictionary/app changes are needed versus when `Vibration Orchestrator` must be extended.

### Step 14: End-to-End Regression and Agent Tests

Owner: Shared.

Goal:

- Prove existing functionality still works and new agent flows are safe.

What to do:

1. Run current app regression:
   - load users
   - add user
   - assign use case
   - load mappings
   - assign mapping
   - edit mappings
   - use dictionary tab
   - use schedule tab
2. Test `/chat` directly:
   - list mappings
   - explain mapping
   - brainstorm mapping
   - refine draft
   - select draft
   - cancel draft
   - commit draft
3. Test expert-panel questions:
   - project architecture
   - use-case explanation
   - required-paper question
   - workflow review
4. Test feedback burden and simulation.
5. Test runtime with `Vibration Orchestrator`.

Deliverable:

- Test results file with pass/fail notes and unresolved issues.

Validation:

- No known existing workflow is broken.
- No mutation occurs without explicit confirmation.
- Runtime uses agent-created mappings correctly.

### Step 15: Rollout

Owner: Shared.

Goal:

- Move the new backend safely into live use.

What to do:

1. Back up the live DB.
2. Apply `agent_artifact_migration.sql`.
3. Import updated n8n workflows.
4. Keep the original InfraNodus template inactive.
5. Test all updated workflows using `/webhook-test/chat`.
6. Publish updated workflows one at a time:
   - `Mapping Manager`
   - `Knowledge Agent`
   - `GraphRAG Expert Panel Agent`
   - `Chat Orchestrator`
7. Start `ResearcherSideApp-FULL`.
8. Run production smoke tests.
9. Document live workflow IDs and rollback procedure.

Deliverable:

- Live Agent V2 rollout note.

Validation:

- JavaFX app can use `/chat`.
- Existing direct app flows still work.
- Agent brainstorm and expert-panel answers work.
- Rollback copies are available.

## Test Cases

### Regression

1. App loads users.
2. App adds a user through `/add-user`.
3. App assigns a use case through `/assign-usecase`.
4. App loads mappings through `/current-configurations`.
5. Direct Mappings tab assignment succeeds.
6. Direct Mappings tab user-specific duplicate succeeds.
7. Chat can list active mappings.
8. Chat can assign an existing mapping to a user.
9. Dictionary tab still lists and edits use-case dictionary entries.
10. Schedule tab still lists and mutates schedules.

### Expert Panel

1. "Explain the HeartRate experiment setup."
2. "How does sensory substitution relate to this use case?"
3. "What would make this mapping gentler for a participant?"
4. "Review this use case before I activate it."

Expected:

- Uses DB/app context when available.
- Uses retrieval/citations when configured.
- Does not mutate DB.
- Returns `reply` plus optional structured fields.

### Brainstorm Flow

1. "Brainstorm gentle mappings for this use case."
2. "Make option 2 less intense."
3. "Select option 2."
4. "Simulate it using recent data."
5. "Create it and assign it to user 100."

Expected:

- Draft artifact exists after step 1.
- Proposal IDs remain stable.
- No DB mapping row is created before commit.
- Commit creates or reuses a mapping.
- Assignment uses deterministic `Mapping Manager` branch.
- Artifact status becomes `committed`.

### Runtime Validation

1. Create or reuse a mapping through Agent V2.
2. Assign it to a user.
3. Send a `/usecase-routing` request to `Vibration Orchestrator`.
4. Confirm the selected user's active mapping is used.
5. Confirm `insert_sensor_data(...)` logs with the correct use case and `fbRangeID`.
6. Confirm rate-limited events log the expected reason.

## Open Decisions

1. Should the first implementation use InfraNodus graphs, OpenAI vector stores, or both?
2. Which required papers must be loaded first for the demo?
3. Should the template workflow be renamed and refactored, or should a new workflow be created from it?
4. Should Release 1 stay with one active mapping per user globally? Recommended: yes.
5. What thresholds define "too frequent" or "too intense" feedback?
6. Should full workflow simulation be Release 1 or Release 2? Recommended: Release 2.

## Final Recommendation

Use the InfraNodus template as the foundation for the agent's reasoning architecture, not as the app-facing workflow.

The best implementation path is:

1. Preserve `/webhook/chat` in `Chat Orchestrator`.
2. Build a project-specific `GraphRAG Expert Panel Agent` from the template.
3. Route broad reasoning and literature/project questions to the expert panel.
4. Keep deterministic DB writes in the existing manager workflows.
5. Add `agent_artifact` so brainstorm and workflow-design conversations can persist across turns.
6. Upgrade JavaFX rendering after the backend response contract is stable.

This gives the system a much stronger AI backend while keeping the current app, DB, and n8n runtime reliable.

