﻿# Smartwatch Haptic Feedback System - Knowledge Base

Last updated: June 13, 2026

This file gives project context for the Smartwatch Haptic Feedback system. It is written so it can later be converted into Notion documentation with separate pages for each major component:

- ResearcherSideApp
- Android app
- Smartwatch app
- n8n workflows
- PostgreSQL database

The documentation goal is to help people working on the system understand the architecture, ownership boundaries, data model, and how the components interact.

## June 13, 2026 source refresh

This update was checked against these local project resources:

- `ResearcherSideApp-FULL`
- `Smartwatch-Haptic-Workflow` exported n8n workflow JSON files
- `Smartwatch-Haptic-Workflow\DB_rule_user.sql`
- `AndroidPhoneHapticFeedBackApp`
- `SmartWatchHapticFeedBackApp1`
- `project_brief.txt`
- `project_abstract.txt`
- `C:\Users\talir\Desktop\final project papers`

Important tooling note: no n8n-specific MCP tools were exposed in this Codex session, so workflow analysis was performed from the exported n8n JSON files in `Smartwatch-Haptic-Workflow` rather than by querying a live n8n MCP server.

Current project framing from the brief and abstract:

- Title: From Sensor Data to Haptic Feedback: A Smartwatch Monitoring System.
- The project continues earlier work on transmitting environmental and physiological data through smartwatch vibrations.
- The new contribution is an AI and n8n automation layer for creating, adapting, and operating personalized haptic workflows.
- The system links physiological data, location, environmental data, and time/context signals to adaptive vibration feedback.
- The researcher-facing goal is a configurable platform for creating, testing, and studying real-time haptic feedback workflows.
- The longer-term interaction goal is an agent-style interface where an operator can conversationally create or refine workflows, for example high-UV alerts or personalized haptic rules.
- The "Physio-to-AI" direction is to stream physiological data into AI models that learn personal patterns and return tailored real-time feedback.

Current implementation deltas confirmed in source:

- The Android phone relay currently uses Retrofit for `/usecase-routing` and `/get-sensor-types`, and Volley for `/monitoring-config?userId=...`.
- The phone validates device identifiers, maps watch message fields into backend payload fields, posts sensor/location payloads to n8n, parses returned `pulses`, `intensity`, `duration`, and `interval`, and forwards vibration commands to the watch.
- The watch app registers hardware sensor command keys for `HeartRate`, `AmbientTemp`, `Light`, and `Pressure`; only registered sensor names auto-start hardware streaming.
- The watch expects `Monitoring:<type>` and `Vibrate:<intensity>,<pulses>,<duration>,<interval>` commands over classic Bluetooth SPP.
- The n8n backend now includes separate manager workflows for chat, mappings, schedules, dictionaries, use-case building, knowledge assistance, DB endpoints, and vibration orchestration.
- The database dump includes `UseCaseDictionary`, `api_pool`, `agent_session`, and `v_agent_context`, which support the AI/dictionary/use-case-builder direction in addition to the core runtime tables.

## Research background from final project papers

The papers in `final project papers` mainly support the project's theoretical and UX grounding in sensory substitution, sensory augmentation, interoception, and haptic feedback.

Relevant takeaways:

- Sensory substitution and augmentation can make otherwise invisible signals perceivable through another sensory channel. This supports the core idea of translating physiological and environmental data into haptic patterns.
- Longitudinal tactile-compass work, including the "sixth sense" and feelSpace-belt studies, shows that vibrotactile orientation feedback can be learned over weeks and may affect behavior, spatial cognition, and subjective perception.
- The "activation, acquisition, integration" learning model is useful for study design: early use may require effort and conscious attention, while later use may become more integrated and automatic.
- FeltRadio is a close HCI precedent for the project because it translates invisible wireless activity into visual/tactile stimuli and studies the experience of making normally hidden environmental signals felt.
- Interoceptive training work is directly relevant to heart-rate haptics: real-time haptic heartbeat feedback improved interoceptive accuracy and confidence more than visual heartbeat feedback in the extracted Psychophysiology 2024 paper.
- Exteroceptive-interoceptive sensory substitution research using respiration translated into visual/auditory stimuli supports the broader "body signal as external feedback" design pattern.
- ThermalSense supports the general engineering pattern of selecting a signal outside normal perception, mapping it into another modality, and evaluating learnability, localization/recognition, and user experience.
- Retinal prosthesis and visual-to-auditory sensory substitution work reinforces the importance of training, automaticity, and subjective transparency when designing sensory feedback systems.

Design implications for this project:

- Do not treat vibration as a simple alert channel only. The research basis supports designing mappings that users can learn, compare, and eventually interpret with less conscious effort.
- Study sessions should separate first-exposure usability from longer-term learning, because early cognitive load may differ from later integration.
- Feedback mappings should be stable enough for learning but configurable enough for personalization and experiment conditions.
- Researcher tools should preserve mapping history and context, because training effects depend on which mapping a participant experienced over time.
- Haptic feedback for physiological signals should be evaluated for user comfort, perceived helpfulness, and body-attention effects, not only technical delivery.

## Relevant repositories and branches

Use these branches when reading the repositories:

| Component | Repository | Branch / checked state |
|---|---|---|
| n8n backend workflows and DB-facing logic | `liranBecher/Smartwatch-Haptic-Workflow` | `main` at `3fb00d8` for the June 8, 2026 merge summary; `user-mapping` has an unmerged later delta |
| Researcher desktop dashboard | `TTaliR/ResearcherSideApp-FULL` | `main` at `4c10460` after merge from `origin/user-mapping` |
| Android phone relay app | `TTaliR/AndroidPhoneHapticFeedBackApp` | `main` |
| Wear OS smartwatch app | `TTaliR/SmartWatchHapticFeedBackApp1` | `main` |

Important branch note: as of the June 8, 2026 summary, `Smartwatch-Haptic-Workflow` has a later `user-mapping` commit, `065532f` (`get all mappings`), that is not contained in `main`. That commit modifies `DB Manager.json` and deletes `DB_user102data_backup.sql`. Review this branch/main mismatch before treating `main` as fully complete.

## Project goal

The system is a research platform for studying and configuring real-time haptic feedback delivered through a smartwatch.

A participant wears a smartwatch. The watch collects sensor data and can vibrate. The Android phone acts as the Bluetooth and network bridge. n8n receives runtime data, enriches it when needed, applies the active mapping for the user/use case, persists state in PostgreSQL, and returns haptic commands. The ResearcherSideApp gives researchers a desktop control plane for managing users, use cases, mappings, schedules, graphs, and assistant/chat workflows.

The core loop is:

1. A participant is associated with devices and one or more mapping assignments.
2. Sensor/context data is collected from the watch and phone.
3. n8n receives the data, enriches it if needed, resolves the active mapping for the user/use case, and decides whether/how to send haptic feedback.
4. The Android phone relays the backend haptic command to the smartwatch.
5. The smartwatch executes the vibration pattern.
6. Researchers use the dashboard to manage configuration and inspect live or historical data.

## High-level architecture

```text
ResearcherSideApp
      |
      | HTTP webhook calls
      v
n8n workflows  <------>  PostgreSQL database
      ^                       ^
      |                       |
      | HTTP POST/GET         | stores configuration, users,
      |                       | mappings, schedules, sensor data,
Android phone relay           | feedback events, assistant context
      ^
      | Bluetooth SPP
      v
Wear OS smartwatch
```

Runtime layers:

1. Smartwatch layer - real-time sensing and vibration execution.
2. Android relay layer - Bluetooth bridge, GPS/context provider, and internet uplink.
3. n8n/backend layer - webhook API, orchestration, enrichment, mapping logic, schedules, and DB access.
4. Database layer - source of truth for configuration, assignments, runtime readings, and histories.
5. Researcher/dashboard layer - human-facing control panel for managing and monitoring the experiment.

The main dependency direction is:

```text
ResearcherSideApp -> n8n -> PostgreSQL
Android app -> n8n -> PostgreSQL
Smartwatch <-> Android app
```

The smartwatch does not talk directly to PostgreSQL or the researcher dashboard. The Android app does not directly update DB tables. The ResearcherSideApp does not directly drive smartwatch vibration; it changes backend/database configuration, and runtime flows use that configuration.

## Component page: ResearcherSideApp

Repository: `TTaliR/ResearcherSideApp-FULL`
Branch/state: `main` at `4c10460` after merge from `origin/user-mapping`

The ResearcherSideApp is a JavaFX/Spring Boot desktop application used by researchers to operate the study. It talks to n8n over HTTP webhooks and is not the system's backend source of truth.

### Responsibilities

- Display users, assigned use cases, assigned mappings, and mapping history.
- Let researchers select users and use cases.
- Show current and historical haptic rules/mappings.
- Create, edit, change, deactivate, or assign mappings.
- Apply mapping edits globally or duplicate/change a mapping for one selected user only.
- Create use cases.
- Manage user names and user-related details.
- Manage schedules, including active/inactive state.
- Show graphs and recent sensor trends through embedded web views.
- Export graph/data outputs.
- Provide a researcher assistant/chat interface that sends selected user/use-case/mapping context to n8n.

### UI/controller structure after June 8, 2026

The app was reorganized from one large dashboard controller into separated tab controllers and FXML views.

Added major controllers/views:

- `AgentChatTabController.java` / `AgentChatTab.fxml`
- `ContextDrawerController.java` / `ContextDrawer.fxml`
- `GraphTabController.java` / `GraphTab.fxml`
- `SchedulesTabController.java` / `SchedulesTab.fxml`
- `YellowBookTabController.java` / `YellowBookTab.fxml`

Other important added files:

- `UserUseCaseMapping.java`
- `DateUtils.java`

Important changed files:

- `DashboardController.java` - heavily refactored and reduced by moving tab-specific behavior into dedicated controllers.
- `Dashboard.fxml` - updated to host the separated tabs and context drawer.
- `ApiService.java` - gained mapping, assignment, schedule, history, and use-case response helpers.
- `User.java` - now stores multiple `UserUseCaseMapping` objects and exposes UI-level current use-case/current-mapping state.
- `Schedule.java` - now includes `nextRunDate` and active status.
- `MappingConfigParser.java` - accepts both `mappingId` and `mapping_id` response shapes.
- `MappingUiFactory.java`, `SharedUiFactory.java`, `YellowBookUiFactory.java`, and `dashboard.css` - updated for card/UI behavior.

### Researcher app API/service behavior

`ApiService` is the central HTTP client for n8n webhook calls. Important dashboard endpoints include:

| Endpoint | Purpose |
|---|---|
| `/get-users` | Return users with active mapping-derived use-case info. |
| `/get-sensor-types` | Return available use cases / monitoring types. |
| `/current-configurations` | Return mapping configurations; after June 8, this may include inactive mappings too. |
| `/users-mappings-history` | Return assignment-level and mapping-level history for a user/use case. |
| `/sensor-data` | Return stored sensor/context readings for graphs and review. |
| `/monitoring-config` | Resolve monitoring configuration for a user. |
| `/set-monitoring-type` | Legacy/related assignment endpoint. Do not assume it is the source of truth if mapping assignment is active. |
| `/assign-usecase` | Assign a user to a use case through mapping logic where supported. |
| `/create-usecase` | Create a new `UseCase`. |
| `/set-rules` | Save haptic mapping rules. |
| `/mapping-activation` | Activate or deactivate a mapping. |
| `/deactivate-mapping` | Legacy/generic mapping deactivation webhook retained in DB Manager. |
| `/set-logging-interval` | Set a use case's logging interval. |
| `/add-user` | Add a user. |
| `/schedule` | Manage schedules. |
| `/chat` | Researcher assistant / mapping manager actions. |
| `/check-connection` | Connectivity test. |
| `/edit-users` | Edit user details. |

New or important helper behavior:

- `EP_GET_USER_MAPPING_HISTORY` maps to `/users-mappings-history`.
- `assignMappingToUser` assigns an existing feedback mapping to a user.
- `changeMapping` applies mapping edits globally.
- `changeMappingForUserOnly` duplicates a mapping, assigns the duplicate to one selected user, and leaves the original mapping unchanged for other users.
- Schedule APIs support list all, list active, add, change, activate, and deactivate.
- Schedule parsing accepts multiple response shapes for IDs and fields, including snake_case and camelCase variants.

### Researcher app mapping behavior

- The UI can parse nested `usecase_mappings` arrays and flat mapping rows from API responses.
- A user can have multiple use-case mappings loaded into the model.
- The current user/use-case selection resolves the correct mapping for that use case.
- Mapping edits distinguish between "apply to all users" and "apply to selected user only".
- Selected-user-only edits are sent as `duplicate_mapping_for_user` requests so shared mappings are not accidentally changed for every assigned user.
- Mapping history can be requested from n8n and displayed as historical mapping cards or assignment timelines.

### Researcher app schedule behavior

- Schedules are rendered as cards rather than only table rows.
- Active and inactive schedules are represented in the UI.
- Schedule cards show user, measure type, trigger percentage, interval, and next check.
- Schedule lists can be filtered by active-only or all schedules.
- The schedules tab refreshes when relevant user/use-case context changes.

### Use-case creation behavior

Use-case creation was improved before the June 8 mapping merge and is important because mapping, chat, graph, and schedule operations depend on stable use-case IDs.

- `ApiService.createUseCase` returns a full JSON response instead of only Boolean success/failure.
- Empty use-case names are rejected.
- Names containing whitespace are rejected.
- Validation failures are returned as structured error JSON.
- The Add Use Case dialog shows inline validation feedback and disables the Add button until the name is valid.
- The UI accepts multiple n8n response shapes:
  - Direct object, such as `{ usecase_id, name, description }`
  - One-item array
  - Object with `data: [...]`
  - Object with `rows: [...]`
- The UI extracts the created use-case ID from `usecase_id`, `usecaseid`, or `id`.
- If no valid ID is returned, the app shows a targeted error and reloads the use-case list.
- On success, the created use case is immediately added to local UI state and selected.
- Chat sending verifies that the selected use-case ID can be resolved before calling n8n.
- Chat payloads include both `usecase_id` and `usecase_name`.

## Component page: Android phone relay app

Repository: `TTaliR/AndroidPhoneHapticFeedBackApp`
Branch: `main`

The Android phone app is the gateway between the smartwatch and the backend.

### Responsibilities

- Maintain the Bluetooth connection to the smartwatch.
- Receive sensor data from the smartwatch.
- Collect contextual data from the phone, especially GPS coordinates.
- Combine smartwatch readings, location, and identifiers into backend requests.
- Send runtime requests to n8n webhook endpoints.
- Receive haptic response instructions from n8n.
- Relay haptic instructions back to the smartwatch over Bluetooth.

### Current phone implementation details

Key classes:

- `MonitoringService` - foreground monitoring orchestration. It identifies the user from the paired watch, loads use cases, fetches the user's active monitoring type, starts Bluetooth monitoring, and throttles sensor forwarding.
- `BluetoothConnectionManager` - connects to the paired watch through classic Bluetooth SPP, sends `Monitoring:<type>`, parses incoming key-value sensor messages, recovers IDs from the watch name when needed, and sends `Vibrate:<intensity>,<pulses>,<duration>,<interval>` commands back to the watch.
- `NetworkController` - owns n8n communication. It uses Retrofit for `/usecase-routing` and `/get-sensor-types`, and Volley for `/monitoring-config?userId=...`.
- `n8nApis` - Retrofit interface for `POST usecase-routing` and `GET get-sensor-types`.
- `LocationController` and `LocationData` - collect and structure latitude/longitude and device identifiers for context-based use cases.

Current backend calls:

| Endpoint | Method | Caller | Purpose |
|---|---|---|---|
| `/monitoring-config?userId=<id>` | GET | `NetworkController` | Resolve the active monitoring type for the parsed user ID. |
| `/get-sensor-types` | GET | `n8nApis` / `NetworkController` | Load available use-case names. |
| `/usecase-routing` | POST | `n8nApis` / `NetworkController` | Send unified sensor/location payloads to Vibration Orchestrator. |

Unified runtime payload fields include:

- `userId`
- `smartWatchId`
- `androidId`
- `type`
- `value`
- `lat`
- `lon`

The phone parses n8n responses for:

- `pulses`
- `intensity`
- `duration`
- `interval`

If `pulses > 0`, the phone forwards the vibration command to the watch.

### Configuration notes

The Android app must be configured with the correct n8n server address. In local development this usually means updating the IP/domain used by the networking layer and ensuring Android network security config allows the selected host.

The Android app should not directly write database tables. It sends payloads to n8n; n8n owns DB writes and mapping decisions.

Current source note: `NetworkController` has a hard-coded ngrok base URL. For local or production runs, this must match the active n8n deployment.

## Component page: Smartwatch app

Repository: `TTaliR/SmartWatchHapticFeedBackApp1`
Branch: `main`

The smartwatch app is the edge device worn by the participant.

### Responsibilities

- Read physiological sensor data, especially heart rate through Wear OS sensor APIs.
- Run as a foreground/background-capable service so monitoring can continue during a session.
- Act as a classic Bluetooth SPP server for the Android phone relay.
- Send sensor readings to the phone over Bluetooth.
- Receive haptic feedback commands from the phone.
- Translate haptic command JSON into actual vibration patterns.

### Current watch implementation details

Key classes:

- `BackgroundMonitoringService` - starts a foreground service, creates a notification channel, holds a wake lock, initializes feedback/Bluetooth controllers, and runs the Bluetooth server on a foreground-priority `HandlerThread`.
- `BluetoothServerManager` - starts the classic Bluetooth SPP server, accepts the phone connection, handles `Monitoring` and `Vibrate` commands, starts registered sensor streams, and sends sensor readings back to the phone.
- `FeedBackController` - wraps Wear OS sensor monitoring and Android `VibrationEffect` waveform execution.

Bluetooth command contract:

| Direction | Format | Meaning |
|---|---|---|
| Phone -> Watch | `Monitoring:<type>` | Set the active monitoring type and start the matching hardware sensor if registered. |
| Watch -> Phone | `MonitoringType:<type>,Value:<value>,UserID:<id>,SmartWatchID:<id>,AndroidID:<id>` | Send a sensor reading and identifiers to the relay. |
| Phone -> Watch | `Vibrate:<intensity>,<pulses>,<duration>,<interval>` | Execute the haptic response returned by n8n. |

Registered watch sensor keys:

- `HeartRate` -> `Sensor.TYPE_HEART_RATE`
- `AmbientTemp` -> `Sensor.TYPE_AMBIENT_TEMPERATURE`
- `Light` -> `Sensor.TYPE_LIGHT`
- `Pressure` -> `Sensor.TYPE_PRESSURE`

The watch vibration engine maps:

- `intensity` to Android vibration amplitude, expected in the `1..255` range.
- `pulses` to the number of vibration bursts.
- `duration` to each pulse duration in milliseconds.
- `interval` to the pause between pulses in milliseconds.

### Device naming convention

The smartwatch device name convention encodes identifiers used by the rest of the system:

```text
UserID-<ID>-SmartWatchID-<ID>
```

Example:

```text
UserID-1-SmartWatchID-1
```

These identifiers help n8n and the DB connect a data point to a user, watch, phone, and use case.

## Component page: n8n workflows

Repository: `liranBecher/Smartwatch-Haptic-Workflow`
Branch/state: `main` at `3fb00d8` for the June 8, 2026 summary

n8n is the backend API and orchestration layer. It exposes webhook endpoints, queries PostgreSQL, calls external APIs, transforms data, decides haptic outputs, and returns responses to the Android app or ResearcherSideApp.

### Important workflow files

- `DB Manager.json` - DB/API management endpoints for users, use cases, mappings, mapping history, sensor data, schedules, monitoring configuration, connectivity checks, mapping activation, and user creation/editing.
- `Vibration Orchestrator.json` - runtime data-processing and vibration-decision workflow. It exposes `/usecase-routing` as the main unified phone relay endpoint and still contains older/direct endpoints for `heartRate`, `sun-data`, `moon-data`, `pollution-data`, and weather routes such as `temperature-data`, `humidity-data`, `precipitation-data`, and `wind-data`.
- `Mapping Manager.json` - assistant/manager workflow for listing, listing all, adding, removing/deactivating, changing, assigning, duplicating-for-user, and brainstorming mappings.
- `Chat Orchestrator.json` - `/chat` webhook and intent router. It validates input, upserts/loads session context, builds an LLM prompt, routes parsed intent to Mapping Manager, Knowledge Agent, Dictionary Manager, Schedule Manager, or Use Case Builder, responds to the dashboard, and saves chat history.
- `Schedule Manager.json` - workflow-triggered manager for schedule actions: list all, list active, add, change, activate, and deactivate. It also deactivates prior schedules of the same type where the add/activate flow requires it.
- `Dictionary Manager.json` - workflow-triggered manager around `UseCaseDictionary` and `api_pool`: list dictionary entries, add/edit/delete entries, delete use cases or parameters, and get parameters for a use-case/API definition.
- `Use Case Builder.json` - workflow-triggered AI builder. It validates builder input, loads dictionary parameters and API metadata, builds an LLM prompt, parses the AI output, and returns a formatted workflow-building reply.
- `Knowledge Agent.json` - workflow-triggered assistant context workflow. It packages current mappings and uses an LLM chain to answer knowledge/context questions.

### Current n8n workflow inventory from exported JSON

| Workflow | Main trigger/interface | Main purpose |
|---|---|---|
| `Chat Orchestrator` | `/chat` POST | Researcher assistant entrypoint and intent router. |
| `DB Manager` | Multiple webhooks | Dashboard and app DB-facing API endpoints. |
| `Vibration Orchestrator` | `/usecase-routing` POST plus legacy/direct sensor endpoints | Runtime haptic decision and persistence flow. |
| `Mapping Manager` | Execute Workflow trigger | Mapping CRUD, assignment, duplication, and brainstorm actions. |
| `Schedule Manager` | Execute Workflow trigger | Schedule CRUD and active/inactive schedule management. |
| `Dictionary Manager` | Execute Workflow trigger | Use-case/API dictionary management. |
| `Use Case Builder` | Execute Workflow trigger | AI-assisted workflow/use-case construction from dictionary/API metadata. |
| `Knowledge Agent` | Execute Workflow trigger | Assistant knowledge response using current mapping context. |

### n8n responsibilities

- Receive sensor/context payloads from the Android phone relay.
- Retrieve users, use cases, mappings, assignment history, schedules, and monitoring configuration.
- Resolve a user's active mapping through `User_UC_Mappings`.
- Apply haptic mapping logic to sensor/context values.
- Enrich context using external APIs, such as astronomy/azimuth or pollution APIs.
- Smooth heart-rate data using recent history when needed.
- Persist sensor data and feedback/alert decisions.
- Support researcher actions from the dashboard.
- Support chat/assistant workflows for researcher-facing DB operations.

### June 8, 2026 n8n changes

Changed files on `main`:

- `Chat Orchestrator.json`
- `DB Manager.json`
- `Mapping Manager.json`
- `DB_rule_user.sql`
- `DB_user102data_backup.sql`

Workflow behavior changes:

- Mapping prompt rules removed `unassign` from the advertised action set.
- Mapping intent now focuses on `list`, `listAll`, `add`, `remove`, `change`, `duplicate_mapping_for_user`, `assign`, and `brainstorm`.
- The chat prompt still carries selected app context:
  - `selected_user_id`
  - `selected_user_mapping_id`
- The prompt instructs the LLM to use the selected mapping ID for phrases like "that mapping" or "the selected mapping".
- The prompt instructs `duplicate_mapping_for_user` to include only changed fields, allowing Mapping Manager to copy unchanged values from the original mapping.
- Explicit unassign routing and nodes were removed from Mapping Manager.
- Assignment support remains through assign validation and DB assignment nodes.
- Duplicate-for-user logic remains and disconnects the previous mapping, inserts a duplicated mapping, inserts the user-mapping row, and formats the duplicate response.
- List-all mapping behavior remains available for showing inactive and active mappings.
- `DB Manager` added `/users-mappings-history`.
- `current-configurations` was broadened from active-only mappings to all mappings by removing the `fcr.active = TRUE` filter.
- Due schedule processing now joins schedules through active `User_UC_Mappings` to find the current use case for a user.

### Mapping history endpoint

Endpoint example:

```text
/webhook/users-mappings-history?useCaseName=AirPressure&userId=101
```

The query joins:

- `User_UC_Mappings`
- `feedback_config_rules`
- `UseCase`

The endpoint returns assignment-level and mapping-level fields, including:

- `assignmentId`
- `userId`
- `mappingId`
- `assignmentActive`
- `assignedAt`
- `deactivatedAt`
- `usecaseId`
- `mappingActive`
- value ranges
- pulse ranges
- intensity ranges
- duration ranges
- interval ranges

## Component page: PostgreSQL database

PostgreSQL stores configuration and runtime data. It is accessed mainly through n8n, not directly by the Android app or smartwatch.

### Conceptual data areas

- Participants and devices - users, watches, phones, and relationships.
- Use cases - experiment/monitoring types such as `HeartRate`, `SunAzimuth`, `MoonAzimuth`, `Pollution`, `AirPressure`, `UVIndex`, etc.
- Haptic mappings - rules in `feedback_config_rules` that map sensor/context value ranges to haptic parameters.
- User-to-mapping assignment - `User_UC_Mappings` connects users to active and historical feedback mappings.
- Runtime data - sensor readings and generated alerts/haptic feedback events.
- Schedules - schedule rules, active/inactive state, next checks, and next run dates.
- Assistant/session context - chat, agent sessions, and Slack/chat context where applicable.
- Use-case/API dictionary - `UseCaseDictionary` and `api_pool` define available external APIs, required parameters, fixed values, and metadata used by Dictionary Manager and Use Case Builder.

### Current seeded use cases in `DB_rule_user.sql`

The SQL dump currently seeds:

| ID | Name | Description / note |
|---|---|---|
| 1 | `HeartRate` | Vibrations based on heart-rate readings; log interval `00:02:00`. |
| 2 | `MoonAzimuth` | Vibrations based on moon position; log interval `00:03:00`. |
| 3 | `SunAzimuth` | Vibrations based on sun position; log interval `00:03:00`. |
| 4 | `AirPressure` | No description in dump; log interval `00:03:00`. |
| 7 | `Pollution` | Air quality monitoring; log interval `00:02:00`. |
| 12 | `UVIndex` | Trial UV index use case; log interval not set in dump. |

### UseCaseDictionary and API pool

The dictionary tables support AI-assisted creation and operation of new use cases.

Examples of dictionary-backed sources and parameters in the dump:

- Open-Meteo UV Index: `url`, `current=uv_index`, `latitude`, `longitude`.
- Open-Meteo Air Pressure: `url`, `current=surface_pressure`, `latitude`, `longitude`.
- Open-Meteo Cloud Cover, Humidity, Temperature, Precipitation, and Wind Speed.
- Sunrise-Sunset API: `url`, `latitude`, `longitude`, optional `date`, and `formatted`.
- Open-Elevation Altitude: `url`, `locations`.
- IPGeolocation Sun Azimuth and Moon Azimuth: `url`, `lat`, `long`, optional `date`, and `apiKey`.
- WAQI Air Quality Index: geo URL with `lat`, `lon`, and `token`.

These tables are used by Dictionary Manager and Use Case Builder to know which parameters are required, which values are fixed, and which external API metadata should be included in AI-generated workflow guidance.

### Agent/session schema

`agent_session` stores assistant context:

- `session_id`
- `researcher_id`
- `current_usecase_id`
- `conversation_history`
- `active_workflow`
- `created_at`
- `updated_at`

`v_agent_context` joins agent session state with `UseCase` and active `feedback_config_rules`, giving assistant workflows a compact context view for the selected use case and current mappings.

### Current user/mapping schema

The newer design separates use cases, mappings, and user assignment:

- `UseCase` defines available monitoring/experiment types.
- `feedback_config_rules` stores mapping rules and links each rule to a `UseCase` through `usecase_id`.
- `User_UC_Mappings` connects a user to a selected mapping in `feedback_config_rules`.
- A user's active monitoring type is not treated as a direct column on `User`; n8n resolves it by joining `User_UC_Mappings -> feedback_config_rules -> UseCase`.

This means the dashboard should show each user's current use case by reading active mapping assignment data, rather than depending on an `active_usecase_id` field in `User`.

### User_UC_Mappings lifecycle model

After the June 8, 2026 database changes, `User_UC_Mappings` models assignment history, not only a current user-to-rule link.

Important columns:

- `id`
- `user_id`
- `feedback_config_rule_id`
- `active`
- `assigned_at`
- `deactivated_at`

Important indexes:

- `user_uc_mappings_one_active_per_user` on `user_id` where `active = true`
- `user_uc_mappings_restore_lookup` on `user_id`, `assigned_at desc`, `id desc`

System meaning:

- Active assignment rows represent the current mapping assignment.
- Inactive rows preserve historical assignment context.
- `assigned_at` and `deactivated_at` allow assignment timelines/history views.
- The active use case is derived from the active assignment's mapping and that mapping's `usecase_id`.

### feedback_config_rules

The haptic mapping table. Each row describes how a value range maps to haptic parameters such as:

- pulses
- intensity
- duration
- interval

In the newer design, each rule references a `UseCase` through `usecase_id`.

After June 8, 2026, shared mappings must be treated carefully:

- A global mapping change can affect all users assigned to that mapping.
- A selected-user-only change should duplicate the mapping and assign the duplicate to that user.
- Inactive mappings may still appear in list-all/current-configuration style responses depending on endpoint behavior.

### Schedule data

Schedule handling now includes active/inactive state and next-run-date handling. n8n due-schedule processing joins schedules through active `User_UC_Mappings` to find the current use case for a user.

Schedule response fields may appear in snake_case or camelCase forms:

- `schedule_id` / `id`
- `user_id` / `userId`
- `measure_type` / `measureType`
- `trigger_percentage` / `triggerPercentage`
- `next_check` / `nextCheck`
- `next_run_date` / `nextRunDate`
- `interval_days` / `intervalDays`
- `active` / `isActive`

### June 8, 2026 database notes

Changes in `DB_rule_user.sql` include:

- `User_UC_Mappings` changed from simple user/rule pairs to historical assignment records with active and deactivated timestamps.
- `User_UC_Mappings.id` is backed by an identity sequence.
- `feedback_config_rules` sequence advanced from 173 to 186.
- `user_schedules` sequence advanced from 7 to 11.
- Schedule 7 for user 100 changed from active to inactive.
- The SQL dump includes added test/conversation history showing assign/unassign/list-all mapping scenarios for `AirPressure`, `UVIndex`, `HeartRate`, and `Pollution`.

`DB_user102data_backup.sql` was added on `main` by commit `3fb00d8`. It appears to be a large backup of user 102 readings using the old schema.

## Main data and control flows

### Flow A - Researcher configures the experiment

```text
ResearcherSideApp UI
      |
      | HTTP request through ApiService
      v
n8n DB Manager / Mapping Manager / Schedule workflows
      |
      | SQL queries / inserts / updates
      v
PostgreSQL
```

Examples:

- Load users: dashboard calls `/get-users`; n8n joins `User`, `User_UC_Mappings`, `feedback_config_rules`, and `UseCase`; dashboard displays users and their active use cases.
- Load use cases: dashboard calls `/get-sensor-types`.
- Create a use case: dashboard calls `/create-usecase`; n8n inserts into `UseCase`; dashboard expects a usable use-case ID in one of several accepted response shapes.
- Load mappings: dashboard calls `/current-configurations`; after June 8, this endpoint may include inactive mappings because the active-only filter was removed.
- Load mapping history: dashboard calls `/users-mappings-history`; n8n returns assignment-level and mapping-level history.
- Save a mapping globally: dashboard calls the relevant mapping endpoint/action; n8n updates the shared mapping.
- Change a mapping for one user: dashboard sends `duplicate_mapping_for_user`; n8n duplicates the mapping and assigns the duplicate to the selected user.
- Assign an existing mapping: dashboard calls assignment behavior; n8n connects the user to an existing `feedback_config_rules` row through `User_UC_Mappings`.
- Manage schedules: dashboard calls `/schedule` with actions like list, add, change, activate, and deactivate.

### Flow B - User/use-case/mapping assignment

```text
Researcher selects user + use case or mapping in dashboard
      |
      | assign existing mapping or duplicate mapping for selected user
      v
n8n DB Manager / Mapping Manager
      |
      | updates/inserts User_UC_Mappings lifecycle rows
      | active assignment points to feedback_config_rules
      v
PostgreSQL
```

The system treats active assignment as `user -> feedback_config_rule`, and the use case is derived from `feedback_config_rules.usecase_id`.

Important concept: this is not just `user -> use case`. The mapping assignment is effectively `user -> feedback_config_rule`, and the use case is derived through the mapping.

### Flow C - Live heart-rate monitoring

```text
Smartwatch
      |
      | Bluetooth: heart-rate reading + identifiers
      v
Android phone relay
      |
      | HTTP POST to n8n with user/watch/phone IDs and value
      v
n8n Vibration Orchestrator
      |
      | DB lookup: active assignment + mapping + recent history
      | decision: haptic params or no vibration
      v
Android phone relay
      |
      | Bluetooth haptic command
      v
Smartwatch vibration engine
```

The watch monitors heart rate. The phone sends heart-rate payloads to n8n. n8n can smooth data using recent readings, evaluate the active mapping rule, store the sensor reading and feedback decision, and return a haptic command. The phone forwards this command to the watch, which performs the vibration.

### Flow D - Location/context-based use cases

```text
Android phone relay
      |
      | GPS coordinates + IDs
      v
n8n Vibration Orchestrator
      |
      | external API enrichment
      | e.g. sun azimuth, moon azimuth, pollution
      v
mapping decision + persistence
      |
      v
haptic response to phone/watch
```

For use cases like `SunAzimuth`, `MoonAzimuth`, or `Pollution`, the phone provides location and identifiers. n8n calls external APIs to derive the context value, applies the corresponding active mapping rule, persists relevant data, and returns haptic parameters.

### Flow E - Researcher graph/data review

```text
ResearcherSideApp
      |
      | /sensor-data or related dashboard endpoints
      v
n8n DB Manager
      |
      | query SensorData / Alert / mappings / use-case context
      v
ResearcherSideApp embedded graph WebView
```

The dashboard fetches data and renders it in embedded HTML graph views. This supports live or post-session inspection of sensor trends and feedback events.

### Flow F - Schedule processing

```text
ResearcherSideApp
      |
      | create/change/activate/deactivate schedule
      v
n8n schedule workflow
      |
      | stores schedule state and next run metadata
      v
PostgreSQL

Later:

n8n due schedule processing
      |
      | joins active User_UC_Mappings to resolve user's current use case
      v
schedule action / monitoring decision
```

Schedule behavior depends on active mapping assignment because the user's current use case is derived from the active mapping.

### Flow G - Researcher assistant and mapping actions

```text
ResearcherSideApp chat/context
      |
      | selected_user_id, selected_user_mapping_id,
      | usecase_id, usecase_name, researcher message
      v
n8n Chat Orchestrator
      |
      | routes mapping intent
      v
n8n Mapping Manager
      |
      | list/listAll/add/remove/change/assign/
      | duplicate_mapping_for_user/brainstorm
      v
PostgreSQL
```

The assistant should use selected app context when resolving ambiguous phrases such as "that mapping" or "the selected mapping". For selected-user-only mapping edits, the intended action is `duplicate_mapping_for_user`.

## Key domain concepts

### User

A participant in the experiment. A user has identifying information, device relationships, schedules, runtime readings, and active/historical mapping assignments.

### Watch

The Wear OS device that collects sensor data and executes vibrations.

### Android phone

The relay device. It handles network communication and location context and bridges between the watch and n8n.

### UseCase

A monitoring or experiment type. Examples include:

- `HeartRate`
- `SunAzimuth`
- `MoonAzimuth`
- `Pollution`
- `AirPressure`
- `UVIndex`

Use cases are important because mappings are defined per use case, and dashboard state is usually scoped by the selected use case.

### feedback_config_rules

The haptic mapping table. Each row links a value range to haptic parameters and references a `UseCase`.

### User_UC_Mappings

The assignment/history table connecting users to feedback rules. It allows each user to have an active mapping and preserves historical assignment records. The active use case is derived from the active assignment's mapping.

### SensorData

Runtime readings received from the smartwatch or derived context APIs. Used for graphs, history, smoothing, and validation.

### Alert / feedback event

The persisted record of a haptic decision or alert generated from a sensor/context value.

### Schedule

A researcher-defined timing rule for scheduled monitoring or checks. Schedules include user, measure type, trigger percentage, interval, next check, next run date, and active/inactive state.

## n8n endpoints used by the dashboard and apps

The exact workflows may include more endpoints, but these are central to the system:

| Endpoint | Typical caller | Purpose |
|---|---|---|
| `/get-users` | ResearcherSideApp | Return users with active mapping-derived use-case info. |
| `/get-sensor-types` | ResearcherSideApp | Return available use cases / monitoring types. |
| `/current-configurations` | ResearcherSideApp | Return haptic mappings; may include active and inactive mappings after June 8 changes. |
| `/users-mappings-history` | ResearcherSideApp | Return mapping assignment history for a user/use case. |
| `/sensor-data` | ResearcherSideApp | Return stored sensor data for graphs/review. |
| `/monitoring-config` | Android app / dashboard | Resolve monitoring configuration for a user. |
| `/set-monitoring-type` | ResearcherSideApp | Legacy/related endpoint for assignment/monitoring context. |
| `/assign-usecase` | ResearcherSideApp | Assign a user to a use case via mapping logic where supported. |
| `/create-usecase` | ResearcherSideApp | Create a new `UseCase`. |
| `/set-rules` | ResearcherSideApp | Save haptic mapping rules. |
| `/mapping-activation` | ResearcherSideApp | Activate or deactivate a mapping row. |
| `/deactivate-mapping` | ResearcherSideApp / legacy | Generic mapping deactivation webhook retained in DB Manager. |
| `/set-logging-interval` | ResearcherSideApp | Set a use case's logging interval. |
| `/add-user` | ResearcherSideApp | Add a user. |
| `/schedule` | ResearcherSideApp | Manage schedules. |
| `/chat` | ResearcherSideApp | Researcher assistant / mapping manager actions. |
| `/check-connection` | ResearcherSideApp | Connectivity test. |
| `/usecase-routing` | Android phone relay | Unified live sensor/location payload route for haptic decisions. |
| `/heartRate` | Android phone relay / legacy | Older direct heart-rate route retained in Vibration Orchestrator. |
| `/sun-data`, `/moon-data`, `/pollution-data` | Android phone relay / legacy | Older direct context routes retained in Vibration Orchestrator. |
| `/temperature-data`, `/humidity-data`, `/precipitation-data`, `/wind-data` | Android phone relay / direct weather routes | Weather-context routes retained in Vibration Orchestrator. |

## Architecture rules and assumptions

- PostgreSQL is the source of truth for users, use cases, mappings, assignments, schedules, sensor readings, and feedback events.
- n8n owns DB access for runtime and dashboard-facing operations.
- ResearcherSideApp should call n8n, not the DB directly.
- Android should call n8n, not the DB directly.
- Smartwatch should only communicate with the Android relay.
- Active use case should be derived from active `User_UC_Mappings -> feedback_config_rules -> UseCase`.
- Do not assume a direct `User.active_usecase_id` is the source of truth.
- Shared mappings may affect multiple users. User-specific edits should duplicate the mapping and assign the duplicate to that user.
- Endpoint response shapes can vary between direct Postgres output, response-node wrappers, arrays, and row/data wrappers. The ResearcherSideApp already handles several variants and future changes should preserve that tolerance.
- Naming, IDs, endpoint URLs, response shapes, and active/inactive flags are common integration risk areas.

## Mental model for future changes

When adding or modifying features, think through all layers:

1. Database - Does the schema represent the new concept correctly, including active/history lifecycle if needed?
2. n8n - Are webhook inputs, SQL queries, action routing, and response formats aligned with the schema?
3. ResearcherSideApp - Does the dashboard call the right endpoint, parse the response shape correctly, and keep selected user/use-case/mapping state consistent?
4. Android app - Does the participant-side flow send IDs, location, and sensor/context data in the format n8n expects?
5. Smartwatch app - Can the watch collect the needed reading and execute the returned haptic command?

Because the system is distributed, bugs often come from mismatches in naming, IDs, endpoint URLs, response shapes, or assumptions about where the active user/use-case/mapping assignment lives.

