﻿# Agent V2 User Stories

Researcher point of view for the Smartwatch Haptic Feedback System.

## Summary

Agent V2 should be more than a command interface. It should help researchers design, validate, personalize, simulate, explain, and document adaptive haptic-feedback workflows through natural conversation.

The most valuable capabilities to prioritize are:

- Draft mode for mappings and workflows.
- Simulation before activation.
- Participant-specific recommendations.
- Feedback-burden detection.
- Workflow review before deployment.
- Natural follow-up memory.

## 1. Agent as a Conversational Experiment Co-Designer

### User Story 1 - Turn a Vague Idea into an Experiment Workflow

As a researcher, I want to describe an experiment idea in natural language, so that the AI agent can help me turn it into a concrete workflow.

Example:

```text
Researcher:
Can we create something around UV exposure and heart rate?

Agent:
Yes. We could create a UV awareness use case where the watch vibrates differently when UV is high, and adapts the feedback if the participant's heart rate is elevated. Do you want the system to focus on outdoor exposure, physiological stress, or behavior change?
```

Expected behavior:

- Ask follow-up questions.
- Suggest relevant data sources.
- Suggest a use-case name.
- Suggest mapping logic.
- Suggest what data should be logged.
- Suggest what should be shown later in analysis.

### User Story 2 - Ask Clarifying Questions Instead of Failing

As a researcher, I want the AI agent to ask intelligent clarification questions when my request is incomplete, so that the conversation feels natural and I do not need to know every required parameter.

Example prompt:

```text
Make the vibration softer for users with high heart rate.
```

Better agent response:

```text
I can do that. Should this change apply to all participants in the HeartRate use case, or only to the currently selected participant? Also, what heart-rate range should count as "high"?
```

Acceptance criteria:

- The agent detects missing details.
- The agent asks only the most necessary question.
- The agent remembers the partially completed request.
- After the researcher answers, the agent continues from the previous step instead of restarting.

### User Story 3 - Guide the Researcher Through a Multi-Step Setup

As a researcher, I want the AI agent to guide me step-by-step through creating a new use case, so that I can build complex workflows without knowing the database or n8n structure.

Example flow:

```text
Researcher: Create a weather-based workflow.
Agent: What weather variable should be used: temperature, rain, UV, humidity, or air quality?
Researcher: UV.
Agent: Should the feedback depend only on UV, or also on heart rate/location/time?
Researcher: UV and time of day.
Agent: Great. I suggest three UV ranges and different vibration intensities. Want me to create a draft?
```

Why this matters: the agent should feel like a design assistant, not only a command parser.

## 2. Agent as a Smart Mapping Assistant

### User Story 4 - Suggest Mappings Based on Experiment Goals

As a researcher, I want to tell the AI agent the goal of the feedback, so that it can suggest suitable vibration mappings.

Example prompt:

```text
I want the vibration to feel noticeable but not stressful when heart rate increases.
```

Agent response idea:

```text
For gradual awareness, I suggest using low pulse count and medium intensity for moderate heart rate, then increasing pulse count before increasing intensity. This avoids making the feedback feel alarming too early.
```

Acceptance criteria:

- The agent suggests mapping ranges.
- The agent explains the reasoning.
- The agent gives the researcher options such as gentle, clear, or urgent.
- The agent does not save changes until the researcher approves.

### User Story 5 - Compare Two Possible Mapping Strategies

As a researcher, I want the AI agent to compare alternative feedback strategies, so that I can choose the one that best fits my experiment.

Example prompt:

```text
Should I increase vibration intensity or number of pulses when heart rate rises?
```

Agent response idea:

```text
You could use intensity to represent severity and pulse count to represent frequency of alerts. If the goal is calm awareness, increase pulse count first. If the goal is warning, increase intensity.
```

Possible UI enhancement:

- Show Option A and Option B.
- Show preview cards.
- Allow "Apply option A" or "Save as draft mapping."

### User Story 6 - Detect Risky or Uncomfortable Feedback Patterns

As a researcher, I want the AI agent to warn me when a vibration mapping may be too intense, too frequent, or confusing, so that I avoid bad participant experiences.

Example prompt:

```text
Set high heart rate to 10 pulses at max intensity every 5 seconds.
```

Agent response idea:

```text
That may be too aggressive for continuous feedback. I recommend lowering the frequency or using escalation only after repeated high readings. Would you like a safer version?
```

Why this feels smart: the agent evaluates whether the requested design makes sense instead of blindly executing commands.

### User Story 7 - Explain an Existing Mapping in Plain Language

As a researcher, I want the AI agent to explain a mapping in simple words, so that I can quickly understand what participants will feel.

Example prompt:

```text
Explain mapping 140 like I'm presenting it to someone.
```

Agent response idea:

```text
Mapping 140 means that when the participant's heart rate enters this range, the watch sends a moderate vibration pattern. As the value increases, the feedback becomes stronger or more frequent, helping the participant notice the physiological change.
```

Possible addition: a presentation-mode explanation for the final project demo.

## 3. Agent as a Participant-Specific Personalization Assistant

### User Story 8 - Recommend Personalization Based on Participant Data

As a researcher, I want the AI agent to analyze a participant's recent sensor data, so that it can recommend whether their feedback mapping should be personalized.

Example prompt:

```text
Does user 12 need a different HeartRate mapping?
```

Agent response idea:

```text
User 12 often reaches the high range during normal activity, so the current mapping may create too many alerts. I suggest raising the threshold or reducing intensity for this user only.
```

Acceptance criteria:

- The agent checks recent data.
- The agent compares participant behavior to the current mapping.
- The agent recommends a change.
- The agent distinguishes between global change and user-specific override.

### User Story 9 - Detect When a Participant Is Receiving Too Many Vibrations

As a researcher, I want the AI agent to notice when a participant receives too many feedback events, so that I can reduce fatigue or annoyance.

Example prompt:

```text
Check if any participants are getting too many alerts.
```

Agent response idea:

```text
User 8 received feedback during 72% of the last monitoring window, mostly from the 90-110 heart-rate range. This may be too frequent. I recommend adjusting that range or adding a cooldown.
```

New feature ideas:

- Feedback burden score.
- Alerts per hour.
- Most-triggered mapping.
- Suggested cooldown.

### User Story 10 - Learn Participant Baseline Before Suggesting Thresholds

As a researcher, I want the AI agent to learn a participant's baseline sensor patterns before suggesting mappings, so that feedback is personalized and meaningful.

Example prompt:

```text
Set up HeartRate feedback for this new participant.
```

Agent response idea:

```text
I recommend collecting baseline heart-rate data for 24 hours before setting final thresholds. For now, I can create a temporary conservative mapping.
```

Why this is useful: the agent becomes adaptive instead of assuming one threshold fits everyone.

### User Story 11 - Explain Why a Participant-Specific Change Is Recommended

As a researcher, I want the AI agent to explain why it recommends changing a participant's mapping, so that I can justify the change scientifically.

Example prompt:

```text
Why do you recommend lowering the intensity for user 15?
```

Agent response idea:

```text
Because user 15 crosses the high-heart-rate threshold frequently during normal walking periods. A high-intensity vibration may over-alert them. Lowering intensity keeps awareness while reducing interruption.
```

## 4. Agent as a Proactive Research Monitor

### User Story 12 - Proactively Surface Unusual Patterns

As a researcher, I want the AI agent to notify me when it detects unusual physiological or environmental patterns, so that I can investigate them without manually reviewing raw data.

Example agent message:

```text
I noticed that user 6 had repeated high-heart-rate readings during low-movement periods yesterday. This may be worth reviewing.
```

Acceptance criteria:

- The agent checks recent sensor data.
- The agent detects anomalies or unusual combinations.
- The agent explains what is unusual.
- The agent suggests next steps, not just a warning.

### User Story 13 - Suggest Workflow Improvements After Observing Data

As a researcher, I want the AI agent to suggest improvements after workflows run for a while, so that the system evolves based on real participant behavior.

Example agent message:

```text
The current UV workflow rarely triggers because the threshold is too high for the collected data. Consider lowering the UV threshold or changing the trigger to time spent outdoors.
```

Why this is powerful: it turns the agent into a continuous experiment optimizer.

### User Story 14 - Detect Ineffective Mappings

As a researcher, I want the AI agent to detect mappings that are never triggered or triggered too often, so that I can improve the experiment configuration.

Example prompt:

```text
Are any mappings useless right now?
```

Agent response idea:

```text
Yes. Mapping 132 was never triggered in the last 7 days. It may be outside the realistic sensor range for this participant group.
```

Possible metrics:

- Never triggered.
- Over-triggered.
- Triggered only for one participant.
- Triggered at unexpected times.
- Duplicates another mapping.

## 5. Agent as a Natural Workflow Builder

### User Story 15 - Create Workflows from Everyday Language

As a researcher, I want to describe a workflow in everyday language, so that the AI agent can translate it into structured n8n logic.

Example prompt:

```text
When the participant is outside, UV is high, and their heart rate is elevated, send a stronger vibration.
```

Agent should produce:

- Data sources: location, UV, heart rate.
- Conditions: outside, UV above threshold, heart rate above baseline.
- Action: stronger vibration pattern.
- Logging: store trigger reason and values.
- Researcher confirmation before creation.

### User Story 16 - Let the Agent Build a Draft Workflow Before Applying It

As a researcher, I want the AI agent to create a draft workflow first, so that I can review the logic before it affects participants.

Example agent response:

```text
I created a draft workflow:
Trigger: every 5 minutes
Conditions: UV > 7 and participant outside
Feedback: 3 pulses, medium intensity
Would you like to activate it, edit it, or simulate it?
```

Why this improves UX: it avoids the risk of the agent making changes too quickly.

### User Story 17 - Simulate a Workflow Before Activation

As a researcher, I want to ask the AI agent to simulate a workflow using sample data, so that I can understand what feedback would be sent before activating it.

Example prompt:

```text
Simulate this workflow for user 4 using yesterday's data.
```

Agent response idea:

```text
Using yesterday's data, this workflow would have triggered 11 times, mostly between 12:00 and 14:00. The strongest vibration would have occurred at 13:20 when UV was high and heart rate was elevated.
```

Potential UI feature:

- Timeline of simulated triggers.
- Count of vibrations.
- Most common trigger reason.
- Suggested changes.

## 6. Agent as a Data Interpreter

### User Story 18 - Ask Natural Questions About Participant Data

As a researcher, I want to ask the AI agent natural questions about sensor data, so that I do not need to manually write queries or inspect graphs.

Example prompts:

- When did user 3 have the highest heart rate this week?
- Was user 7 outdoors when the vibration triggered?
- Which users had the most feedback events?
- Did the schedule run correctly yesterday?

Acceptance criteria:

- The agent translates questions into database queries or workflow checks.
- The answer includes the relevant time range.
- The agent explains the result in plain language.
- The agent can offer to show a graph or export data.

### User Story 19 - Explain Graph Trends Conversationally

As a researcher, I want the AI agent to explain trends shown in the graph, so that I can interpret data faster.

Example prompt:

```text
What am I seeing in this graph?
```

Agent response idea:

```text
The graph shows repeated heart-rate increases around the same time of day. The current mapping is triggered during most of these increases, which means the participant likely received frequent feedback during that period.
```

Why it feels smarter: the agent connects visual data, mapping rules, and participant experience.

### User Story 20 - Connect Physiological and Environmental Context

As a researcher, I want the AI agent to explain relationships between physiological data and environmental data, so that I can study how context affects feedback.

Example prompt:

```text
Was high heart rate related to high UV or location?
```

Agent response idea:

```text
There were 8 high-heart-rate events. 6 occurred while the participant was outside, and 5 overlapped with high UV. This suggests the UV workflow may be relevant, but more data is needed.
```

## 7. Agent as an Experiment Safety and Quality Checker

### User Story 21 - Review a Workflow Before Deployment

As a researcher, I want the AI agent to review a workflow before I activate it, so that it can identify missing conditions, overly frequent triggers, or unclear feedback logic.

Example prompt:

```text
Review this workflow before I activate it.
```

Agent response idea:

```text
I see three possible issues: the workflow has no cooldown, it may trigger repeatedly during long outdoor periods, and the vibration intensity jumps sharply between medium and high. I recommend adding a cooldown and smoother escalation.
```

### User Story 22 - Suggest Cooldowns and Limits

As a researcher, I want the AI agent to recommend cooldown periods, so that participants are not overwhelmed by repeated vibrations.

Example prompt:

```text
How often should this feedback be allowed to trigger?
```

Agent response idea:

```text
For awareness feedback, I suggest no more than once every 10-15 minutes unless the value becomes critical. For warning feedback, shorter cooldowns may be acceptable.
```

### User Story 23 - Detect Conflicting Workflows

As a researcher, I want the AI agent to warn me when two workflows might trigger similar vibrations at the same time, so that participants do not receive confusing feedback.

Example agent message:

```text
The UV workflow and HeartRate workflow can both trigger medium-intensity pulses during outdoor activity. Consider using different vibration patterns or combining them into one adaptive workflow.
```

## 8. Agent as a Natural Conversation Partner

### User Story 24 - Remember References Like "That Mapping"

As a researcher, I want the AI agent to understand references from earlier in the conversation, so that I can speak naturally.

Example flow:

```text
Researcher: Create a mapping for high heart rate.
Agent: Here is a draft mapping.
Researcher: Make that one less intense.
Agent: Sure - I'll reduce the intensity in the draft mapping.
```

Acceptance criteria:

- The agent tracks recent entities: mapping, user, use case, workflow.
- The agent resolves "that", "this", "the previous one", and "the selected user".
- If the reference is ambiguous, it asks a short clarification question.

### User Story 25 - Maintain an Editable Draft During Conversation

As a researcher, I want the AI agent to keep a draft configuration during the conversation, so that I can iteratively refine it before saving.

Example flow:

```text
Create a gentle heart-rate mapping.
Make the high range stronger.
Add a cooldown.
Show me the final version.
Save it.
```

Why this matters: this creates a natural design flow rather than forcing each message to be a separate command.

### User Story 26 - Confirm Risky Actions Before Applying Them

As a researcher, I want the AI agent to confirm actions that affect participants, so that accidental changes are prevented.

Example response:

```text
This will update mapping 140 for all users assigned to HeartRate. Do you want to apply it globally or create a user-specific copy?
```

Action classes:

- Safe actions: explain, list, simulate, suggest.
- Risky actions: activate workflow, change mapping, assign mapping, delete/deactivate schedule.

Risky actions should require confirmation.

### User Story 27 - Explain What It Is About to Do Before Doing It

As a researcher, I want the AI agent to summarize planned changes before applying them, so that I can verify the intent.

Example response:

```text
I understood that you want to:

1. Create a new UV use case.
2. Use UV index as the input.
3. Trigger stronger vibration when UV is high.
4. Apply it to user 4 only.

Should I create this as a draft?
```

## 9. Agent as a Bridge Between Researcher and System Implementation

### User Story 28 - Translate Researcher Intent into Technical Implementation

As a researcher, I want the AI agent to explain how my natural-language request maps to system components, so that I understand what will change behind the scenes.

Example prompt:

```text
What will happen if I approve this?
```

Agent response idea:

```text
If approved, I will create a new feedback mapping in feedback_config_rules, connect it to the selected use case, and assign it to user 12 through the user-use-case mapping.
```

Why useful: this gives transparency and helps during the final project presentation.

### User Story 29 - Generate Implementation Tasks for Developers

As a researcher/developer, I want the AI agent to turn an idea into implementation tasks, so that we can decide what needs to be built next.

Example prompt:

```text
What do we need to implement so the agent can simulate workflows?
```

Agent response idea:

```text
To support simulation, we need:

1. A backend endpoint for historical sensor data.
2. A workflow simulation function.
3. A frontend preview panel.
4. A response format for simulated trigger events.
```

## 10. Agent as a Report and Presentation Assistant

### User Story 30 - Generate a Summary of Experiment Configuration

As a researcher, I want the AI agent to summarize the current experiment setup, so that I can use it in presentations, documentation, or reports.

Example prompt:

```text
Summarize the HeartRate experiment setup for the project poster.
```

Agent response idea:

```text
The HeartRate use case collects physiological data from the smartwatch and converts selected heart-rate ranges into haptic feedback patterns. Researchers can configure mappings, assign them to participants, and personalize feedback through the AI agent.
```

### User Story 31 - Explain Participant Flow

As a researcher, I want the AI agent to explain what happens to a participant from data collection to vibration, so that I can communicate the system clearly.

Agent response should include:

- smartwatch/mobile data collection
- data sent to n8n/backend
- rule or AI analysis
- mapping selection
- vibration feedback
- logging for later research

## Priority Backlog

### P0 - Highest Demo Value

- Draft mode for mappings/workflows.
- Simulation before activation.
- Participant-specific recommendations.
- Feedback burden detection.
- Workflow review before deployment.
- Natural follow-up memory.

### P1 - Strong Researcher Experience

- Conversational experiment co-design.
- Mapping strategy comparison.
- Plain-language mapping explanations.
- Data trend interpretation.
- Technical implementation explanations.

### P2 - Future Expansion

- Proactive anomaly notifications.
- Continuous workflow optimization.
- Conflicting workflow detection.
- Report/poster generation.

## Final Project Framing

The AI agent is not only a command interface, but a research assistant that helps design, validate, personalize, and explain adaptive haptic-feedback workflows through natural conversation.

